<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT'].'/grocery/dbcon.php');

// 1) Check POST method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Invalid request method.'];
    header('Location: ../category.php');
    exit;
}

// 2) CSRF Token Validation
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['msg'] = ['type' => 'danger', 'msg' => 'CSRF token mismatch.'];
    header('Location: ../category.php');
    exit;
}

// 3) Validate category ID
if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Invalid category ID.'];
    header('Location: ../category.php');
    exit;
}

$cid = (int)$_POST['id'];

// Check if category exists
$stmt = $conn->prepare("SELECT * FROM category WHERE cid = ?");
$stmt->bind_param("i", $cid);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Category not found.'];
    header('Location: ../category.php');
    exit;
}
$stmt->close();

// Check if this category has sub-categories
$stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM category WHERE parent_id = ?");
$stmt->bind_param("i", $cid);
$stmt->execute();
$count = $stmt->get_result()->fetch_assoc()['cnt'];
$stmt->close();

if ($count > 0) {
    $_SESSION['msg'] = [
        'type' => 'warning',
        'msg'  => "Cannot delete this category. It has $count sub-category(s)."
    ];
    header('Location: ../category.php');
    exit;
}

// Delete products in this category
$stmt = $conn->prepare("DELETE FROM product WHERE cid = ?");
$stmt->bind_param("i", $cid);
$stmt->execute();
$stmt->close();

// Delete the category
$stmt = $conn->prepare("DELETE FROM category WHERE cid = ?");
$stmt->bind_param("i", $cid);
$stmt->execute();
$stmt->close();

// Success message
$_SESSION['msg'] = [
    'type' => 'success',
    'msg'  => 'Category deleted successfully.'
];

header('Location: ../category.php');
exit;
