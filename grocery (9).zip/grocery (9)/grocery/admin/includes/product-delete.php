<?php
session_start();
require '../../dbcon.php'; // adjust path if needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['msg'] = ['type' => 'danger', 'msg' => 'CSRF token mismatch.'];
        header('Location: ../product.php');
        exit;
    }

    $pid = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    if ($pid > 0) {
        // Check if product exists in any order_items
        $stmtCheck = $conn->prepare("SELECT COUNT(*) as cnt FROM order_items WHERE pid = ?");
        $stmtCheck->bind_param("i", $pid);
        $stmtCheck->execute();
        $resCheck = $stmtCheck->get_result()->fetch_assoc();

        if ($resCheck['cnt'] > 0) {
            $_SESSION['msg'] = [
                'type' => 'warning',
                'msg' => 'Cannot delete product! It is already part of existing orders.'
            ];
        } else {
            // Safe to delete
            $stmtDel = $conn->prepare("DELETE FROM product WHERE pid = ?");
            $stmtDel->bind_param("i", $pid);

            if ($stmtDel->execute()) {
                $_SESSION['msg'] = ['type' => 'success', 'msg' => 'Product deleted successfully!'];
            } else {
                $_SESSION['msg'] = ['type' => 'danger', 'msg' => 'Failed to delete product.'];
            }

            $stmtDel->close();
        }
        $stmtCheck->close();
    } else {
        $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Invalid product ID.'];
    }
}

header('Location: ../product.php');
exit;
