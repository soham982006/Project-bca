<?php
session_start();
require '../dbcon.php';

if(!isset($_GET['uid'])){
    $_SESSION['msg'] = "Invalid user!";
    header("Location: users.php");
    exit;
}

$uid = intval($_GET['uid']);

// Fetch user data
$result = $conn->query("SELECT * FROM user WHERE uid=$uid");
if($result->num_rows == 0){
    $_SESSION['msg'] = "User not found!";
    header("Location: users.php");
    exit;
}
$user = $result->fetch_assoc();

// Update user
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = $conn->real_escape_string($_POST['name']);
    $mobile = $conn->real_escape_string($_POST['mobile']);
    $address = $conn->real_escape_string($_POST['address1']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $username = $conn->real_escape_string($_POST['username']);
    $status = $conn->real_escape_string($_POST['status']);

    $sql = "UPDATE user SET 
            name='$name', 
            mobile='$mobile', 
            address1='$address', 
            gender='$gender', 
            username='$username', 
            status='$status'
            WHERE uid=$uid";

    if($conn->query($sql)){
        $_SESSION['msg'] = "User updated successfully!";
        header("Location: users.php");
        exit;
    } else {
        $error = "Error: ".$conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Edit User | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="content-header">
  <div class="container-fluid">
    <h2>Edit User</h2>
    <?php if(isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
  </div>
</div>

<section class="content">
  <div class="container-fluid">
    <div class="card card-primary">
      <div class="card-body">
        <form method="post">
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" class="form-control" required>
          </div>

          <div class="form-group">
            <label>Mobile</label>
            <input type="text" name="mobile" value="<?= $user['mobile'] ?>" class="form-control" required>
          </div>

          <div class="form-group">
            <label>Address</label>
            <input type="text" name="address1" value="<?= htmlspecialchars($user['address1']) ?>" class="form-control">
          </div>

          <div class="form-group">
            <label>Gender</label>
            <select name="gender" class="form-control" required>
              <option value="male" <?= $user['gender']=='male'?'selected':'' ?>>Male</option>
              <option value="female" <?= $user['gender']=='female'?'selected':'' ?>>Female</option>
            </select>
          </div>

          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" class="form-control" required>
          </div>

          <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control">
              <option value="Active" <?= $user['status']=='Active'?'selected':'' ?>>Active</option>
              <option value="Inactive" <?= $user['status']=='Inactive'?'selected':'' ?>>Inactive</option>
            </select>
          </div>

          <button type="submit" class="btn btn-success">Update</button>
          <a href="users.php" class="btn btn-secondary">Cancel</a>
        </form>
      </div>
    </div>
  </div>
</section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>
</body>
</html>
