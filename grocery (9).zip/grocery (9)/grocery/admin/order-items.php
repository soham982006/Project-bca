<?php
session_start();
require '../dbcon.php';

// Validate order ID
if (!isset($_GET['oid']) || !is_numeric($_GET['oid'])) {
    echo "<h3 style='color:red;text-align:center;'>Invalid Order ID!</h3>";
    exit;
}
$oid = intval($_GET['oid']);

// Fetch order info
$order_sql = "
    SELECT o.oid, o.uid, o.total, o.date, o.status, u.name AS customer
    FROM ord o
    LEFT JOIN user u ON o.uid = u.uid
    WHERE o.oid = $oid
";
$order_res = $conn->query($order_sql);
if (!$order_res || $order_res->num_rows === 0) {
    echo "<h3 style='color:red;text-align:center;'>Order not found!</h3>";
    exit;
}
$order = $order_res->fetch_assoc();

// Fetch order items
$item_sql = "
    SELECT oi.item_id, p.name, p.pic, oi.quantity, oi.amount, oi.subtotal
    FROM order_items oi
    JOIN product p ON oi.pid = p.pid
    WHERE oi.oid = $oid
";
$item_res = $conn->query($item_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Order #<?= $oid ?> | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<!-- AdminLTE & Bootstrap -->
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
<link rel="stylesheet" href="dist/css/adminlte.min.css">

<style>
body { background: #f4f6f9; }
.table img { max-width: 60px; border-radius: 6px; }
.table td, .table th { vertical-align: middle; text-align: center; }
.status-badge {
  padding: 6px 10px;
  border-radius: 12px;
  font-size: 13px;
  color: #fff;
}
.status-Pending { background: #f0ad4e; }
.status-Processing { background: #5bc0de; }
.status-Shipped { background: #0275d8; }
.status-Delivered { background: #5cb85c; }
.status-Canceled { background: #d9534f; }
</style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <h2 class="mb-3">Order Details</h2>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">

      <!-- Order Info -->
      <div class="card card-primary">
        <div class="card-body">
          <p>
            <strong>Order ID:</strong> #<?= $order['oid'] ?><br>
            <strong>Customer:</strong> <?= htmlspecialchars($order['customer'] ?? 'Guest') ?><br>
            <strong>Status:</strong>
            <span class="status-badge status-<?= htmlspecialchars($order['status']) ?>">
              <?= htmlspecialchars($order['status']) ?>
            </span><br>
            <strong>Date:</strong> <?= date("d M Y, h:i A", strtotime($order['date'])) ?><br>
            <strong>Total:</strong> ₹<?= number_format($order['total'], 2) ?>
          </p>
        </div>
      </div>

      <!-- Order Items -->
      <div class="card card-secondary">
        <div class="card-header">
          <h3 class="card-title">Ordered Products</h3>
        </div>
        <div class="card-body">
          <table id="orderItemsTable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Product</th>
                <th>Image</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($item_res && $item_res->num_rows > 0): 
                  $i = 1;
                  while ($row = $item_res->fetch_assoc()):
                      $imgPath = "../images/" . $row['pic'];
                      $img = (file_exists($imgPath) && !empty($row['pic']))
                          ? $imgPath : "../images/no-image.png";
              ?>
              <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><img src="<?= $img ?>" alt="<?= htmlspecialchars($row['name']) ?>"></td>
                <td><?= intval($row['quantity']) ?></td>
                <td>₹<?= number_format($row['amount'], 2) ?></td>
                <td>₹<?= number_format($row['subtotal'], 2) ?></td>
              </tr>
              <?php endwhile; else: ?>
              <tr><td colspan="6" class="text-center text-muted">No items found for this order.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<!-- Scripts -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>

<script>
$(function(){
  $("#orderItemsTable").DataTable({
    responsive: true,
    autoWidth: false,
    ordering: true,
    pageLength: 10,
    buttons: ["copy", "csv", "excel", "pdf", "print"]
  }).buttons().container().appendTo('#orderItemsTable_wrapper .col-md-6:eq(0)');
});
</script>

</body>
</html>
