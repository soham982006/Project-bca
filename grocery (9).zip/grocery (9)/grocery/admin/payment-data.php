<?php
require '../dbcon.php'; // Database connection

$sql = "SELECT p.payid, p.oid, p.uid, p.total_amount, p.payment_type, 
               u.name AS customer_name, o.status AS order_status
        FROM payment p
        LEFT JOIN user u ON p.uid = u.uid
        LEFT JOIN ord o ON p.oid = o.oid
        ORDER BY p.payid DESC";

$result = $conn->query($sql);
?>

<table id="paymentsTable" class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>Payment ID</th>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>Payment Type</th>
            <th>Order Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td>#<?= $row['payid'] ?></td>
            <td>#<?= $row['oid'] ?></td>
            <td><?= htmlspecialchars($row['customer_name'] ?? 'Guest') ?></td>
            <td>₹ <?= number_format($row['total_amount'], 2) ?></td>
            <td><?= htmlspecialchars($row['payment_type']) ?></td>
            <td><?= htmlspecialchars($row['order_status']) ?></td>
            <td>
                <button class="btn btn-sm btn-danger delete-payment" data-id="<?= $row['payid'] ?>">
                    <i class="fa fa-trash"></i> Delete
                </button>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
