<?php
session_start();
require '../dbcon.php';

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Validate Product ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['msg'] = ['type'=>'warning','msg'=>'Invalid product ID.'];
    header('Location: product.php'); exit;
}
$pid = (int)$_GET['id'];

// Fetch product
$stmt = $conn->prepare("SELECT * FROM product WHERE pid=?");
$stmt->bind_param("i", $pid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $_SESSION['msg'] = ['type'=>'warning','msg'=>'Product not found.'];
    header('Location: product.php'); exit;
}
$product = $result->fetch_assoc();
$stmt->close();

// Fetch categories
$cat_sql = "SELECT cid, name FROM category ORDER BY name ASC";
$cat_result = $conn->query($cat_sql);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['msg'] = ['type'=>'danger','msg'=>'CSRF token mismatch.'];
        header('Location: product-edit.php?id='.$pid); exit;
    }

    $name     = trim($_POST['name']);
    $price    = (float)$_POST['price'];
    $discount = (int)$_POST['discount'];
    $weight   = trim($_POST['weight']);
    $cid      = (int)$_POST['cid'];
    $remove_image = isset($_POST['remove_image']);

    // Normalize existing filename (strip any "images/")
    $pic_name = ltrim(str_replace("images/", "", $product['pic']), '/');

    // Handle new image upload
    if (isset($_FILES['pic']) && $_FILES['pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['pic']['tmp_name'];
        $fileName    = $_FILES['pic']['name'];
        $fileExt     = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg','jpeg','png','gif'];

        if (in_array($fileExt, $allowed_ext)) {
            // Delete old file
            if ($pic_name && file_exists('../images/'.$pic_name)) {
                unlink('../images/'.$pic_name);
            }
            $pic_name = uniqid() . '.' . $fileExt;
            move_uploaded_file($fileTmpPath, '../images/' . $pic_name);
        } else {
            $_SESSION['msg'] = ['type'=>'warning','msg'=>'Invalid image format. Allowed: jpg, jpeg, png, gif.'];
            header('Location: product-edit.php?id='.$pid); exit;
        }
    } elseif ($remove_image) {
        if ($pic_name && file_exists('../images/'.$pic_name)) {
            unlink('../images/'.$pic_name);
        }
        $pic_name = null;
    }

    // Update database
    $stmt = $conn->prepare("UPDATE product SET name=?, price=?, discount=?, weight=?, pic=?, cid=? WHERE pid=?");
    $stmt->bind_param("sdissii", $name, $price, $discount, $weight, $pic_name, $cid, $pid);

    if ($stmt->execute()) {
        $_SESSION['msg'] = ['type'=>'success','msg'=>'Product updated successfully!'];
    } else {
        $_SESSION['msg'] = ['type'=>'danger','msg'=>'Failed to update product.'];
    }
    $stmt->close();
    header('Location: product.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Product | Admin</title>
<?php include_once('includes/style.php'); ?>
<style>
.product-img-preview {
    max-width: 150px;
    max-height: 150px;
    margin-top: 10px;
    border-radius: 5px;
    object-fit: contain;
    display: none;
}
.current-img {
    max-width: 150px;
    max-height: 150px;
    margin-bottom: 10px;
    border-radius: 5px;
    object-fit: contain;
}
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="content-header">
    <div class="container-fluid">
        <h1>Edit Product</h1>
        <a href="product.php" class="btn btn-secondary mb-2">Back to Products</a>
    </div>
</div>

<section class="content">
<div class="container-fluid">

<?php if(!empty($_SESSION['msg'])): ?>
<div class="alert alert-<?= $_SESSION['msg']['type'] ?> alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <?= $_SESSION['msg']['msg'] ?>
</div>
<?php unset($_SESSION['msg']); endif; ?>

<div class="card">
    <div class="card-body">
        <form method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="form-group">
                <label for="name">Product Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?= $product['price'] ?>" required>
            </div>

            <div class="form-group">
                <label for="discount">Discount (%)</label>
                <input type="number" class="form-control" id="discount" name="discount" value="<?= $product['discount'] ?>" min="0" max="100">
            </div>

            <div class="form-group">
                <label for="weight">Weight (e.g., 1kg, 250gm)</label>
                <input type="text" class="form-control" id="weight" name="weight" value="<?= htmlspecialchars($product['weight']) ?>" required>
            </div>

            <div class="form-group">
                <label for="cid">Category</label>
                <select class="form-control" id="cid" name="cid" required>
                    <option value="">Select Category</option>
                    <?php while($cat = $cat_result->fetch_assoc()): ?>
                        <option value="<?= $cat['cid'] ?>" <?= $cat['cid']==$product['cid'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="pic">Product Image</label>
                <?php
                $currentImage = $product['pic'] ? ltrim(str_replace("images/", "", $product['pic']), '/') : null;
                $imgPath = $currentImage && file_exists("../images/".$currentImage) ? "../images/".$currentImage : "../images/no-image.png";
                ?>
                <div>
                    <img src="<?= $imgPath ?>" alt="Current Image" class="current-img">
                </div>
                <input type="file" class="form-control" id="pic" name="pic" accept="image/*">
                <div class="form-check mt-1">
                    <input type="checkbox" class="form-check-input" id="remove_image" name="remove_image">
                    <label class="form-check-label" for="remove_image">Remove existing image</label>
                </div>
                <img id="picPreview" class="product-img-preview" alt="Image Preview">
            </div>

            <button type="submit" class="btn btn-success">Update Product</button>
        </form>
    </div>
</div>

</div>
</section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<?php include_once('includes/script.php'); ?>
<script>
// Preview new image before upload
document.getElementById('pic').addEventListener('change', function(){
    const [file] = this.files;
    const preview = document.getElementById('picPreview');
    if(file){
        preview.src = URL.createObjectURL(file);
        preview.style.display = 'block';
    } else {
        preview.style.display = 'none';
    }
});
</script>
</body>
</html>
