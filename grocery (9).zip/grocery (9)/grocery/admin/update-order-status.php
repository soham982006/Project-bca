<?php
session_start();
require '../dbcon.php';
header('Content-Type: application/json');

// Ensure only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

// CSRF validation
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 'error', 'message' => 'CSRF token mismatch']);
    exit;
}

// Validate input
$oid    = isset($_POST['oid']) ? (int) $_POST['oid'] : 0;
$status = isset($_POST['status']) ? trim($_POST['status']) : '';

$allowed_status = ['Pending','Processing','Shipped','Delivered','Canceled'];

if ($oid <= 0 || !in_array($status, $allowed_status)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    exit;
}

// Update order status
$stmt = $conn->prepare("UPDATE ord SET status = ? WHERE oid = ?");
$stmt->bind_param("si", $status, $oid);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Order status updated']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
}

$stmt->close();
$conn->close();
