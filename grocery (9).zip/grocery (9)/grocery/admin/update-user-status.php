<!-- <?php
require '../dbcon.php';
if(isset($_POST['uid'], $_POST['status'])){
    $uid = intval($_POST['uid']);
    $status = $_POST['status'] == 'Active' ? 'Active' : 'Inactive';
    $stmt = $conn->prepare("UPDATE user SET status=? WHERE uid=?");
    $stmt->bind_param("si", $status, $uid);
    if($stmt->execute()){
        echo "success";
    } else {
        echo "error";
    }
}
?> -->
