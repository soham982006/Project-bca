<?php
require '../dbcon.php';
$statuses = ['Pending','Processing','Shipped','Delivered','Canceled'];
$data = [];
foreach($statuses as $st){
    $res = $conn->query("SELECT COUNT(*) AS c FROM ord WHERE status='$st'");
    $row = $res->fetch_assoc();
    $data[$st] = $row['c'];
}
echo json_encode($data);
