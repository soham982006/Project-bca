<?php
session_start();
require '../dbcon.php';

if(isset($_GET['fid'])) {
    $fid = intval($_GET['fid']);
    if($conn->query("DELETE FROM feedback WHERE fid=$fid")) {
        $_SESSION['msg'] = "Feedback deleted successfully!";
    } else {
        $_SESSION['msg'] = "Failed to delete feedback!";
    }
}
header('Location: feedback.php');
exit;
