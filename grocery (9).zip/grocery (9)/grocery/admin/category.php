<?php
session_start();
require '../dbcon.php';

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Fetch all categories with parent names
$sql = "SELECT c1.cid, c1.name, c2.name AS parent 
        FROM category c1 
        LEFT JOIN category c2 ON c1.parent_id = c2.cid 
        ORDER BY c1.cid DESC";
$result = $conn->query($sql);
$total_category = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Categories | AdminLTE</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

  <!-- AdminLTE Styles -->
  <?php include_once('includes/style.php'); ?>

  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include_once('includes/header.php'); ?>
  <!-- /.navbar -->

  <!-- Sidebar -->
  <?php include_once('includes/sidebar.php'); ?>
  <!-- /.sidebar -->

  <!-- Content Wrapper -->
  <div class="content-wrapper">

    <!-- Page Header -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">All Categories (<?= $total_category ?>)</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="homepage.php">Home</a></li>
              <li class="breadcrumb-item active">Categories</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-header -->

    <!-- Main Content -->
    <section class="content">
      <div class="container-fluid">

        <!-- Alerts -->
        <?php
        if (!empty($_SESSION['msg'])) {
          echo '<div class="alert alert-' . $_SESSION['msg']['type'] . ' alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert">&times;</button>'
                  . $_SESSION['msg']['msg'] .
                '</div>';
          unset($_SESSION['msg']);
        }
        ?>

        <!-- Category Table -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Category List</h3>
            <a href="category-add.php" class="btn btn-primary float-right">
              <i class="fa fa-plus-circle"></i> Add New
            </a>
          </div>

          <div class="card-body">
            <table id="categoryTable" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Parent</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($total_category > 0) { 
                  while ($row = $result->fetch_assoc()) { 

                    // Check if this category has children
                    $stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM category WHERE parent_id = ?");
                    $stmt->bind_param("i", $row['cid']);
                    $stmt->execute();
                    $childCount = (int)$stmt->get_result()->fetch_assoc()['cnt'];
                    $stmt->close();
                ?>
                  <tr>
                    <td><?= $row['cid'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= $row['parent'] ? htmlspecialchars($row['parent']) : "—" ?></td>
                    <td>
                      <a href="category-edit.php?id=<?= $row['cid'] ?>" class="btn btn-info btn-sm">
                        <i class="fa fa-edit"></i> Edit
                      </a>

                      <!-- Delete Form -->
                      <form method="post" action="includes/category-delete.php" class="d-inline delete-form">
                        <input type="hidden" name="id" value="<?= $row['cid'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        
                        <?php if ($childCount > 0) { ?>
                            <!-- Disable button if category has sub-categories -->
                            <button type="button" class="btn btn-danger btn-sm" disabled title="Cannot delete: has <?= $childCount ?> sub-category(s)">
                              <i class="fa fa-trash"></i> Delete
                            </button>
                        <?php } else { ?>
                            <button type="button" class="btn btn-danger btn-sm delete-btn">
                              <i class="fa fa-trash"></i> Delete
                            </button>
                        <?php } ?>
                      </form>
                    </td>
                  </tr>
                <?php } } ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
    <!-- /.Main Content -->

  </div>
  <!-- /.content-wrapper -->

  <!-- Footer -->
  <?php include_once('includes/footer.php'); ?>
</div>
<!-- ./wrapper -->

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Confirm Deletion</h5>
        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this category?
        <br><small class="text-muted">This action cannot be undone.</small>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDelete">Yes, Delete</button>
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
<?php include_once('includes/script.php'); ?>

<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function () {
    $("#categoryTable").DataTable({
      "responsive": true,
      "lengthChange": true,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#categoryTable_wrapper .col-md-6:eq(0)');
  });

  // Delete Modal Handling
  let formToSubmit = null;

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      formToSubmit = this.closest('form');
      $('#deleteModal').modal('show');
    });
  });

  document.getElementById('confirmDelete').addEventListener('click', function() {
    if (formToSubmit) formToSubmit.submit();
  });
</script>

</body>
</html>
