<?php
session_start();
require '../dbcon.php';

if(isset($_GET['uid']) && isset($_GET['action'])){
    $uid = intval($_GET['uid']);
    $action = $_GET['action'];

    if($action == 'deactivate'){
        $sql = "UPDATE user SET status='Inactive' WHERE uid=$uid";
        $msg = "User deactivated successfully!";
    } elseif($action == 'activate'){
        $sql = "UPDATE user SET status='Active' WHERE uid=$uid";
        $msg = "User activated successfully!";
    } else {
        $_SESSION['msg'] = "Invalid action!";
        header("Location: users.php");
        exit;
    }

    if($conn->query($sql)){
        $_SESSION['msg'] = $msg;
    } else {
        $_SESSION['msg'] = "Error: ".$conn->error;
    }
}
header("Location: users.php");
exit;
?>
