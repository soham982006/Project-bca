<?php
session_start();
require '../dbcon.php';

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Fetch all products with category names
$sql = "SELECT p.pid, p.name, p.price, p.discount, p.weight, p.pic, c.name AS category
        FROM product p
        LEFT JOIN category c ON p.cid = c.cid
        ORDER BY p.pid DESC";
$result = $conn->query($sql);
$total_product = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Products | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<?php include_once('includes/style.php'); ?>

<!-- DataTables CSS -->
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

<style>
.product-img {
    max-width: 100px;
    max-height: 100px;
    object-fit: contain;
    display: block;
    margin: 0 auto;
    border-radius: 5px;
}
.table-responsive { overflow-x: auto; }
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">All Products (<?= $total_product ?>)</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="homepage.php">Home</a></li>
                    <li class="breadcrumb-item active">Products</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
<div class="container-fluid">

<?php if (!empty($_SESSION['msg'])): ?>
    <div class="alert alert-<?= $_SESSION['msg']['type'] ?> alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <?= $_SESSION['msg']['msg'] ?>
    </div>
    <?php unset($_SESSION['msg']); ?>
<?php endif; ?>

<div class="card table-responsive">
    <div class="card-header">
        <h3 class="card-title">Product List</h3>
        <a href="product-add.php" class="btn btn-primary float-right">
            <i class="fa fa-plus-circle"></i> Add New
        </a>
    </div>
    <div class="card-body">
        <table id="productTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <th>Weight</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($total_product > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['pid'] ?></td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['category'] ?? '—') ?></td>
                            <td><?= number_format($row['price'], 2) ?></td>
                            <td><?= $row['discount'] ?>%</td>
                            <td><?= htmlspecialchars($row['weight']) ?></td>
                            <td>
                                <?php
                                $imgPath = "../images/" . ($row['pic'] ?: "no-image.png");
                                if (!file_exists($imgPath)) $imgPath = "../images/no-image.png";
                                ?>
                                <img src="<?= $imgPath ?>" class="product-img" alt="<?= htmlspecialchars($row['name']) ?>">
                            </td>
                            <td>
                                <a href="product-edit.php?id=<?= $row['pid'] ?>" class="btn btn-info btn-sm">
                                    <i class="fa fa-edit"></i> Edit
                                </a>
                                <form method="post" action="includes/product-delete.php" class="d-inline delete-form">
                                    <input type="hidden" name="id" value="<?= $row['pid'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm delete-btn">
                                        <i class="fa fa-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</div>
</section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirm Deletion</h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this product? <br>
                <small class="text-muted">This action cannot be undone.</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Yes, Delete</button>
            </div>
        </div>
    </div>
</div>

<?php include_once('includes/script.php'); ?>

<!-- DataTables JS -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
$(function () {
    $("#productTable").DataTable({
        responsive: true,
        autoWidth: false,
        lengthChange: true,
        buttons: ["copy","csv","excel","pdf","print","colvis"]
    }).buttons().container().appendTo('#productTable_wrapper .col-md-6:eq(0)');

    let formToSubmit = null;
    $('.delete-btn').click(function(){
        formToSubmit = $(this).closest('form');
        $('#deleteModal').modal('show');
    });
    $('#confirmDelete').click(function(){
        if(formToSubmit) formToSubmit.submit();
    });
});
</script>

</body>
</html>
