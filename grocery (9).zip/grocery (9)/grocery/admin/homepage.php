<?php
session_start();
include '../dbcon.php'; // Make sure this path is correct

if (!isset($_SESSION['uname'])) {
    $_SESSION['error'] = "You are not authorised to access this page without login";
    header('location:index.php');
    exit();
}

// Fetch real-time counts
$totalOrders     = $conn->query("SELECT COUNT(*) as cnt FROM ord")->fetch_assoc()['cnt'];
$totalProducts   = $conn->query("SELECT COUNT(*) as cnt FROM product")->fetch_assoc()['cnt'];
$totalCategories = $conn->query("SELECT COUNT(*) as cnt FROM category")->fetch_assoc()['cnt'];
$totalUsers      = $conn->query("SELECT COUNT(*) as cnt FROM user")->fetch_assoc()['cnt'];
$totalPayments   = $conn->query("SELECT COUNT(*) as cnt FROM payment")->fetch_assoc()['cnt'];
$totalFeedbacks  = $conn->query("SELECT COUNT(*) as cnt FROM feedback")->fetch_assoc()['cnt'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grocery Store | Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />
    <?php include_once('includes/style.php'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__shake" src="dist/img/generated-image.png" alt="AdminLTELogo" height="72" width="72">
    </div>

    <!-- Navbar -->
    <?php include_once('includes/header.php'); ?>

    <!-- Sidebar -->
    <?php include_once('includes/sidebar.php'); ?>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <!-- Content Header -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="homepage.php">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?= $totalOrders ?></h3>
                                <p>Total Orders</p>
                            </div>
                            <div class="icon"><i class="ion ion-bag"></i></div>
                            <a href="orders.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?= $totalProducts ?></h3>
                                <p>Total Products</p>
                            </div>
                            <div class="icon"><i class="ion ion-cube"></i></div>
                            <a href="product.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?= $totalCategories ?></h3>
                                <p>Total Categories</p>
                            </div>
                            <div class="icon"><i class="ion ion-folder"></i></div>
                            <a href="category.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3><?= $totalUsers ?></h3>
                                <p>Total Users</p>
                            </div>
                            <div class="icon"><i class="ion ion-person-add"></i></div>
                            <a href="users.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6 mt-3">
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3><?= $totalPayments ?></h3>
                                <p>Total Payments</p>
                            </div>
                            <div class="icon"><i class="ion ion-card"></i></div>
                            <a href="payment.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6 mt-3">
                        <div class="small-box bg-secondary">
                            <div class="inner">
                                <h3><?= $totalFeedbacks ?></h3>
                                <p>Total Feedbacks</p>
                            </div>
                            <div class="icon"><i class="ion ion-chatbubble-working"></i></div>
                            <a href="feedback.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </section>
    </div>

    <!-- Footer -->
    <?php include_once('includes/footer.php'); ?>
</div>

<?php include_once('includes/script.php'); ?>
</body>
</html>
