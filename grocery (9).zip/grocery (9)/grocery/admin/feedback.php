<?php
session_start();
require '../dbcon.php';

// Fetch all feedbacks with optional user info
$result = $conn->query("SELECT * FROM feedback ORDER BY fid DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Feedback Management | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="content-header">
  <div class="container-fluid">
    <h2>Feedback Management</h2>
    <?php if(isset($_SESSION['msg'])): ?>
      <div class="alert alert-info"><?= $_SESSION['msg']; unset($_SESSION['msg']); ?></div>
    <?php endif; ?>
  </div>
</div>

<section class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Mobile</th>
              <th>Message</th>
              <th>User Info</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $i = 1;
            while($row = $result->fetch_assoc()): ?>
              <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['mobile']) ?></td>
                <td><?= htmlspecialchars($row['msg']) ?></td>
                <td>
                  <?php if($row['uid']): 
                      $uid = $row['uid'];
                      $userResult = $conn->query("SELECT name, mobile, address1, gender, username FROM user WHERE uid = $uid");
                      $user = $userResult->fetch_assoc();
                  ?>
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#userModal<?= $row['fid'] ?>">View User Info</button>

                    <!-- User Info Modal -->
                    <div class="modal fade" id="userModal<?= $row['fid'] ?>" tabindex="-1" role="dialog" aria-labelledby="userModalLabel<?= $row['fid'] ?>" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="userModalLabel<?= $row['fid'] ?>">User Information</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
                            <p><strong>Mobile:</strong> <?= htmlspecialchars($user['mobile']) ?></p>
                            <p><strong>Address:</strong> <?= htmlspecialchars($user['address1']) ?></p>
                            <p><strong>Gender:</strong> <?= htmlspecialchars($user['gender']) ?></p>
                            <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php else: ?>
                    <span class="text-muted">Guest</span>
                  <?php endif; ?>
                </td>
                <td>
                  <a href="delete-feedback.php?fid=<?= $row['fid'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this feedback?');">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
