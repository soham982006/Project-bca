<?php
session_start();
require '../dbcon.php';

// ✅ Generate CSRF token if not already set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ✅ Define possible order statuses
$statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Canceled'];

// ✅ Get counts safely using prepared statements
$status_counts = [];
foreach ($statuses as $st) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM ord WHERE status = ?");
    $stmt->bind_param("s", $st);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $status_counts[$st] = $res['c'] ?? 0;
}
$total_orders = array_sum($status_counts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Orders | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<?php include_once('includes/style.php'); ?>
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

<style>
.table td, .table th { vertical-align: middle; }
.status-pending { background-color: #fff3cd !important; }
.status-processing { background-color: #cce5ff !important; }
.status-shipped { background-color: #d1ecf1 !important; }
.status-delivered { background-color: #d4edda !important; }
.status-canceled { background-color: #f8d7da !important; }
</style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">

  <!-- Header -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6"><h1 class="m-0">Orders (<?= $total_orders ?>)</h1></div>
        <div class="col-sm-6">
          <form id="statusFilterForm" class="form-inline float-sm-right">
            <label class="mr-2">Filter by Status:</label>
            <select id="statusFilter" class="form-control mr-2">
              <option value="">All (<?= $total_orders ?>)</option>
              <?php foreach($statuses as $st): ?>
                <option value="<?= $st ?>"><?= $st ?> (<?= $status_counts[$st] ?>)</option>
              <?php endforeach; ?>
            </select>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Orders Table -->
  <section class="content">
    <div class="container-fluid">
      <div class="card">
        <div class="card-header"><h3 class="card-title">Orders List</h3></div>
        <div class="card-body">
          <div id="ordersData">
            <!-- Orders Table Loaded via AJAX -->
          </div>
        </div>
      </div>
    </div>
  </section>

</div>

<?php include_once('includes/footer.php'); ?>
</div>

<?php include_once('includes/script.php'); ?>

<!-- Toast Container -->
<div id="toast-container" style="position: fixed; top: 20px; right: 20px; z-index: 2000;"></div>

<!-- DataTables Scripts -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>

<script>
$(function(){

  // ✅ Load all orders on page load
  loadOrders($("#statusFilter").val());

  // ✅ Filter by status
  $("#statusFilter").change(function(){
    loadOrders($(this).val());
  });

  // ✅ Load Orders via AJAX
  function loadOrders(status){
    $("#ordersData").html("<p class='text-center text-muted'>Loading orders...</p>");
    $.get("orders-data.php", { status: status })
      .done(function(data){
        $("#ordersData").html(data);

        // ✅ Initialize DataTable
        let table = $("#ordersTable").DataTable({
          responsive:true,
          autoWidth:false,
          destroy:true,
          buttons:["copy","csv","excel","pdf","print","colvis"]
        });
        table.buttons().container().appendTo('#ordersTable_wrapper .col-md-6:eq(0)');

        // ✅ Handle status dropdown change
        $(".status-dropdown").off("change").on("change", function(){
          let oid = $(this).data("id");
          let newStatus = $(this).val();
          let row = $(this).closest("tr");

          $.post("update-order-status.php", {
            oid: oid,
            status: newStatus,
            csrf_token: "<?= $_SESSION['csrf_token'] ?>"
          }, function(res){
            if(res.status === "success"){
              // Change background color safely
              row.removeClass(function(i, c){
                return (c.match(/(^|\s)status-\S+/g) || []).join(' ');
              }).addClass("status-" + newStatus.toLowerCase());

              showToast(res.message, 'success');
              updateCounts();
            } else {
              showToast(res.message, 'danger');
            }
          }, "json");
        });

      })
      .fail(function(){
        $("#ordersData").html("<p class='text-danger text-center'>Failed to load orders.</p>");
      });
  }

  // ✅ Update the count beside each filter
  function updateCounts(){
    $.get("orders-count.php", function(counts){
      let total = 0;
      for(let st in counts){
        total += parseInt(counts[st]);
        $("#statusFilter option[value='"+st+"']").text(st + " (" + counts[st] + ")");
      }
      $("#statusFilter option[value='']").text("All (" + total + ")");
    }, "json");
  }

});

// ✅ Show notification
function showToast(message, type='info'){
  let toast = $(`<div class="toast bg-${type} text-white" data-delay="3000">
    <div class="toast-body">${message}</div>
  </div>`);
  $('#toast-container').append(toast);
  toast.toast('show');
  toast.on('hidden.bs.toast', function(){ $(this).remove(); });
}
</script>
</body>
</html>
