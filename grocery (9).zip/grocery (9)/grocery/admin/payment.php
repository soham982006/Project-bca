<?php
session_start();
require '../dbcon.php';

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payments | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<?php include_once('includes/style.php'); ?>

<!-- DataTables CSS -->
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

<style>
.table td, .table th { vertical-align: middle; }
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6"><h1 class="m-0">Payments</h1></div>
      </div>
    </div>
  </div>

  <section class="content">
    <div class="container-fluid">
      <div class="card">
        <div class="card-header"><h3 class="card-title">Payments List</h3></div>
        <div class="card-body">
          <?php
          // ✅ Fetch payments with order and user info
          $sql = "
            SELECT 
              p.payid, 
              p.oid, 
              p.uid, 
              p.total_amount, 
              p.payment_type,
              u.name AS customer_name,
              o.date AS order_date
            FROM payment p
            LEFT JOIN user u ON p.uid = u.uid
            LEFT JOIN ord o ON p.oid = o.oid
            ORDER BY p.payid DESC
          ";
          $result = $conn->query($sql);
          ?>

          <table id="paymentsTable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Payment ID</th>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Payment Type</th>
                <th>Order Date</th>
              </tr>
            </thead>
            <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
              <tr>
                <td>#<?= $row['payid'] ?></td>
                <td>#<?= $row['oid'] ?></td>
                <td><?= htmlspecialchars($row['customer_name'] ?? 'Guest') ?></td>
                <td>₹ <?= number_format($row['total_amount'], 2) ?></td>
                <td><?= htmlspecialchars($row['payment_type']) ?></td>
                <td><?= date('d M Y, h:i A', strtotime($row['order_date'])) ?></td>
              </tr>
            <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<?php include_once('includes/script.php'); ?>

<!-- DataTables JS -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
$(document).ready(function(){
    let table = $("#paymentsTable").DataTable({
        responsive: true,
        autoWidth: false,
        buttons: ["copy","csv","excel","pdf","print","colvis"]
    });
    table.buttons().container().appendTo('#paymentsTable_wrapper .col-md-6:eq(0)');
});
</script>
</body>
</html>
