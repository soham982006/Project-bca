<?php
session_start();
require '../dbcon.php';

$result = $conn->query("SELECT * FROM user ORDER BY uid DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Users | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="content-header">
  <div class="container-fluid">
    <h2>Users</h2>
    <?php if(isset($_SESSION['msg'])): ?>
      <div class="alert alert-info"><?= $_SESSION['msg']; unset($_SESSION['msg']); ?></div>
    <?php endif; ?>
  </div>
</div>

<section class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-body">
        <table id="usersTable" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Mobile</th>
              <th>Address</th>
              <th>Gender</th>
              <th>Username</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $i=1;
            while($row = $result->fetch_assoc()): ?>
              <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= $row['mobile'] ?></td>
                <td><?= htmlspecialchars($row['address1']) ?></td>
                <td><?= $row['gender'] ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td>
                  <span class="badge <?= $row['status']=='Active'?'badge-success':'badge-secondary' ?>">
                    <?= $row['status'] ?>
                  </span>
                </td>
                <td>
                  <!-- Edit button -->
                  <a href="edit-user.php?uid=<?= $row['uid'] ?>" class="btn btn-sm btn-primary">Edit</a>

                  <!-- Activate/Deactivate -->
                  <?php if($row['status']=='Active'): ?>
                    <a href="delete-user.php?uid=<?= $row['uid'] ?>&action=deactivate" class="btn btn-sm btn-warning">Deactivate</a>
                  <?php else: ?>
                    <a href="delete-user.php?uid=<?= $row['uid'] ?>&action=activate" class="btn btn-sm btn-success">Activate</a>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script>
$(function () {
  $("#usersTable").DataTable({
    responsive: true,
    autoWidth: false
  });
});
</script>
</body>
</html>
