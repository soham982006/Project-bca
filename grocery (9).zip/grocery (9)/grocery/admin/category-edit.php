<?php
session_start();
require '../dbcon.php';

// Validate category id
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Invalid category!'];
    header("Location: category.php");
    exit;
}

$cid = (int)$_GET['id'];

// Fetch category
$stmt = $conn->prepare("SELECT * FROM category WHERE cid = ?");
$stmt->bind_param("i", $cid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Category not found!'];
    header("Location: category.php");
    exit;
}
$category = $result->fetch_assoc();
$stmt->close();

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $parent_id = isset($_POST['parent_id']) && $_POST['parent_id'] !== '' ? (int)$_POST['parent_id'] : 0;

    if ($name !== '') {
        $stmt = $conn->prepare("UPDATE category SET name = ?, parent_id = ? WHERE cid = ?");
        $stmt->bind_param("sii", $name, $parent_id, $cid);

        if ($stmt->execute()) {
            $_SESSION['msg'] = ['type' => 'success', 'msg' => 'Category updated successfully!'];
        } else {
            $_SESSION['msg'] = ['type' => 'danger', 'msg' => 'Error updating category: ' . $stmt->error];
        }

        $stmt->close();
        header("Location: category.php");
        exit;
    } else {
        $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Category name cannot be empty!'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Category | Grocery Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

  <!-- AdminLTE Styles -->
  <?php include_once('includes/style.php'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include_once('includes/header.php'); ?>

  <!-- Sidebar -->
  <?php include_once('includes/sidebar.php'); ?>

  <!-- Content Wrapper -->
  <div class="content-wrapper">

    <!-- Page Header -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Edit Category</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="homepage.php">Home</a></li>
              <li class="breadcrumb-item"><a href="category.php">Categories</a></li>
              <li class="breadcrumb-item active">Edit</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <section class="content">
      <div class="container-fluid">

        <!-- Alerts -->
        <?php if (!empty($_SESSION['msg'])): ?>
          <div class="alert alert-<?= $_SESSION['msg']['type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['msg']['msg'] ?>
            <button type="button" class="close" data-dismiss="alert">&times;</button>
          </div>
          <?php unset($_SESSION['msg']); ?>
        <?php endif; ?>

        <!-- Category Form -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Update Category</h3>
          </div>

          <form method="post" action="">
            <div class="card-body">
              <!-- Category Name -->
              <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" class="form-control" id="name" name="name" 
                       value="<?= htmlspecialchars($category['name']) ?>" required style="text-transform: none;">
              </div>

              <!-- Parent Category -->
              <div class="form-group">
                <label for="parent_id">Parent Category</label>
                <select class="form-control" id="parent_id" name="parent_id">
                  <option value="0">— None —</option>
                  <?php
                  $result = $conn->query("SELECT * FROM category WHERE cid != $cid ORDER BY name ASC");
                  if ($result && $result->num_rows > 0) {
                      while ($row = $result->fetch_assoc()) {
                          $selected = ($row['cid'] == $category['parent_id']) ? 'selected' : '';
                          echo '<option value="'.$row['cid'].'" '.$selected.'>'.trim($row['name']).'</option>';
                      }
                  }
                  ?>
                </select>
              </div>
            </div>

            <!-- Buttons -->
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update Category</button>
              <a href="category.php" class="btn btn-secondary">Cancel</a>
            </div>
          </form>
        </div>

      </div>
    </section>

  </div>

  <!-- Footer -->
  <?php include_once('includes/footer.php'); ?>
</div>

<!-- Scripts -->
<?php include_once('includes/script.php'); ?>
</body>
</html>
