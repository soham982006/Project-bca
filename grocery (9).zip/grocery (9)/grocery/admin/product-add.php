<?php
session_start();
require '../dbcon.php';

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Fetch categories for dropdown
$cat_sql = "SELECT cid, name FROM category ORDER BY name ASC";
$cat_result = $conn->query($cat_sql);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['msg'] = ['type' => 'danger', 'msg' => 'CSRF token mismatch.'];
        header('Location: product-add.php');
        exit;
    }

    // Collect inputs
    $name     = trim($_POST['name']);
    $price    = (float)$_POST['price'];
    $discount = (int)$_POST['discount'];
    $weight   = trim($_POST['weight']);
    $cid      = (int)$_POST['cid'];

    // Handle image upload
    $pic_name = null;
    if (isset($_FILES['pic']) && $_FILES['pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['pic']['tmp_name'];
        $fileName    = $_FILES['pic']['name'];
        $fileExt     = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg','jpeg','png','gif'];

        if (in_array($fileExt, $allowed_ext)) {
            // Generate unique filename & save to /images
            $pic_name = uniqid() . '.' . $fileExt;
            $dest_path = '../images/' . $pic_name;
            move_uploaded_file($fileTmpPath, $dest_path);
        } else {
            $_SESSION['msg'] = ['type' => 'warning', 'msg' => 'Invalid image format. Allowed: jpg, jpeg, png, gif.'];
            header('Location: product-add.php');
            exit;
        }
    }

    // Insert product (binding: s=string, d=double, i=int, s=string, s=string, i=int)
    $stmt = $conn->prepare("INSERT INTO product (name, price, discount, weight, pic, cid) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdissi", $name, $price, $discount, $weight, $pic_name, $cid);

    if ($stmt->execute()) {
        $_SESSION['msg'] = ['type' => 'success', 'msg' => 'Product added successfully!'];
    } else {
        $_SESSION['msg'] = ['type' => 'danger', 'msg' => 'Failed to add product.'];
    }

    $stmt->close();
    header('Location: product.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Product | Admin</title>
<link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />

<?php include_once('includes/style.php'); ?>
<style>
.product-img-preview {
    max-width: 120px;
    max-height: 120px;
    margin-top: 10px;
    border-radius: 5px;
    object-fit: contain;
    display: none;
}
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="content-header">
    <div class="container-fluid">
        <h1>Add New Product</h1>
        <a href="product.php" class="btn btn-secondary mb-2">Back to Products</a>
    </div>
</div>

<section class="content">
<div class="container-fluid">

    <?php if (!empty($_SESSION['msg'])): ?>
        <div class="alert alert-<?= $_SESSION['msg']['type'] ?> alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?= $_SESSION['msg']['msg'] ?>
        </div>
        <?php unset($_SESSION['msg']); ?>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="form-group">
                    <label for="name">Product Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>

                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                </div>

                <div class="form-group">
                    <label for="discount">Discount (%)</label>
                    <input type="number" class="form-control" id="discount" name="discount" value="0" min="0" max="100">
                </div>

                <div class="form-group">
                    <label for="weight">Weight (e.g., 1kg, 250gm)</label>
                    <input type="text" class="form-control" id="weight" name="weight" required>
                </div>

                <div class="form-group">
                    <label for="cid">Category</label>
                    <select class="form-control" id="cid" name="cid" required>
                        <option value="">Select Category</option>
                        <?php while ($cat = $cat_result->fetch_assoc()): ?>
                            <option value="<?= $cat['cid'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="pic">Product Image</label>
                    <input type="file" class="form-control" id="pic" name="pic" accept="image/*">
                    <img id="picPreview" class="product-img-preview" src="#" alt="Image Preview">
                </div>

                <button type="submit" class="btn btn-success">Add Product</button>
            </form>
        </div>
    </div>

</div>
</section>
</div>

<?php include_once('includes/footer.php'); ?>
</div>

<?php include_once('includes/script.php'); ?>
<script>
// Preview image before upload
document.getElementById('pic').addEventListener('change', function(){
    const [file] = this.files;
    const preview = document.getElementById('picPreview');
    if (file) {
        preview.src = URL.createObjectURL(file);
        preview.style.display = 'block';
    } else {
        preview.style.display = 'none';
    }
});
</script>
</body>
</html>
