<?php
session_start();
$hasError = isset($_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Grocery Store | Log in</title>
  <link rel="icon" type="image/x-icon" href="../images/generated-image.ico" />


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <style>
    :root{
      --g-bg-1:#f0f7f2;
      --g-bg-2:#e8f3ea;
      --g-leaf:#3a7d44;
      --g-leaf-2:#5aa469;
      --g-accent:#ffb84d;
      --g-text:#1e2a1f;
      --g-muted:#6b7c6b;
      --g-card:#ffffffcc;
      --g-shadow: 0 10px 30px rgba(0,0,0,.08);
    }
    html,body{height:100%;}
    body.hold-transition.login-page{
      background: radial-gradient(1200px 600px at 10% 10%, var(--g-bg-2), transparent),
                  radial-gradient(1200px 600px at 90% 90%, var(--g-bg-1), transparent),
                  linear-gradient(135deg, #f6fff8 0%, #edf7ef 100%);
      color: var(--g-text);
      overflow-x:hidden;
    }

    /* Floating leaf animation */
    .leaf{
      position: absolute;
      width: 18px; height: 18px;
      background: linear-gradient(145deg, var(--g-leaf), var(--g-leaf-2));
      border-radius: 4px 50% 4px 50%;
      opacity:.12;
      filter: blur(.2px);
      animation: drift 14s linear infinite;
      transform-origin: center;
    }
    .leaf.l1{top:12%; left:8%; animation-delay: -.5s; transform: rotate(20deg);}
    .leaf.l2{top:78%; left:12%; animation-delay: -3s; transform: rotate(60deg);}
    .leaf.l3{top:22%; right:10%; animation-delay: -6s; transform: rotate(-15deg);}
    .leaf.l4{bottom:8%; right:20%; animation-delay: -9s; transform: rotate(35deg);}
    @keyframes drift{
      0%{ transform: translateY(0) rotate(0deg); }
      50%{ transform: translateY(-25px) rotate(180deg); }
      100%{ transform: translateY(0) rotate(360deg); }
    }

    .login-box{
      width: 100%;
      max-width: 420px;
      margin: 3rem auto;
      opacity:0; transform: translateY(8px);
      animation: fadeUp .5s ease-out .05s both;
    }

    .card.card-outline.card-primary{
      border: none;
      background: var(--g-card);
      backdrop-filter: blur(6px);
      box-shadow: var(--g-shadow);
      border-radius: 16px;
      overflow: hidden;
    }

    .card-header{
      background: linear-gradient(135deg, var(--g-leaf), var(--g-leaf-2));
      padding: 28px 20px;
      border-bottom: none;
    }
    .brand{
      display:flex; align-items:center; justify-content:center; gap:.6rem;
      color:#fff; text-decoration:none;
    }
    .brand .logo{
      width:42px; height:42px; border-radius:12px;
      background:#fff2; display:grid; place-items:center;
      border:1px solid #ffffff22;
      transition: transform .3s ease;
    }
    .brand:hover .logo{
      transform: rotate(-6deg) translateY(-2px);
    }
    .brand .logo i{ color:#fff; }
    .brand .title{
      font-size: clamp(24px, 3.2vw, 28px);
      letter-spacing:.5px;
      font-weight:700;
    }
    .brand .title b{ font-weight:800; }

    .card-body{ padding: 26px 22px 28px; }

    .login-box-msg{
      margin:0 0 12px;
      font-size: .95rem;
      color: #c0392b;
    }

    .form-label{
      font-weight:600;
      color: var(--g-muted);
      font-size:.9rem;
      margin-bottom:.35rem;
    }

    .input-group .form-control{
      border-radius: 12px 0 0 12px;
      border-color:#e3efe5;
      padding:.9rem .95rem;
      transition: box-shadow .2s ease, transform .06s ease;
    }
    .input-group-text{
      border-radius: 0 12px 12px 0;
      background:#f2faf4;
      border-color:#e3efe5;
      color: var(--g-leaf);
    }
    .form-control:focus{
      box-shadow: 0 0 0 0.25rem rgba(58,125,68,.15);
      transform: translateY(-1px) scale(1.01);
      border-color:#cfe8d4;
    }

    .btn-primary{
      position: relative;
      overflow: hidden;
      background: linear-gradient(135deg, var(--g-leaf), var(--g-leaf-2));
      border:none;
      padding:.9rem 1.1rem;
      border-radius:12px;
      font-weight:700;
      letter-spacing:.2px;
      box-shadow: 0 8px 18px rgba(58,125,68,.25);
      transition: transform .08s ease, box-shadow .2s ease, filter .2s ease;
    }
    .btn-primary:hover{
      transform: translateY(-2px);
      box-shadow: 0 12px 24px rgba(58,125,68,.28);
      filter: saturate(1.05);
    }
    .btn-primary:active{
      transform: translateY(0);
      box-shadow: 0 6px 14px rgba(58,125,68,.22);
    }
    /* Radial highlight following cursor */
    .btn-primary::after{
      content:"";
      position:absolute; inset:0;
      background: radial-gradient(120px 120px at var(--x,50%) var(--y,50%), rgba(255,255,255,.25), transparent 60%);
      opacity:0; transition: opacity .25s ease;
      pointer-events:none;
    }
    .btn-primary:hover::after{ opacity:.8; }

    .helper{
      display:flex; align-items:center; justify-content:space-between;
      margin-top:.6rem; gap:.5rem; color: var(--g-muted);
      font-size:.9rem;
    }
    .helper a{ color: var(--g-leaf-2); text-decoration:none; }
    .helper a:hover{ text-decoration: underline; }

    .badge-accent{
      display:inline-flex; align-items:center; gap:.4rem;
      background:#fff7ea; color:#7a4b00; border:1px solid #ffe1b3;
      padding:.35rem .6rem; border-radius:999px; font-size:.8rem; font-weight:700;
      margin: 14px 0 8px;
    }
    .badge-accent i{ color: var(--g-accent); }

    /* Valid pulse */
    .form-control.is-valid{
      animation: okPulse .28s ease-out;
      border-color:#b9e4c3;
      box-shadow: 0 0 0 .2rem rgba(58,125,68,.12);
    }
    @keyframes okPulse{
      0%{ transform: scale(1.01); }
      100%{ transform: scale(1); }
    }

    /* Card shake on error */
    .card.shake{ animation: shake .32s ease; }
    @keyframes shake{
      0%,100%{ transform: translateX(0); }
      20%{ transform: translateX(-6px); }
      40%{ transform: translateX(6px); }
      60%{ transform: translateX(-4px); }
      80%{ transform: translateX(2px); }
    }

    /* Subtle entrance */
    @keyframes fadeUp{
      from{ opacity:0; transform: translateY(8px); }
      to{ opacity:1; transform: translateY(0); }
    }

    /* Top progress line */
    .progress-top{
      position:fixed; top:0; left:0; height:3px; width:0;
      background: linear-gradient(90deg, #3a7d44, #5aa469, #ffb84d);
      box-shadow: 0 2px 8px rgba(0,0,0,.08);
      z-index:1050; transition: width .9s ease;
    }
    .progress-top.active{ width: 100%; }

    /* Responsive tweaks */
    @media (max-width: 420px){
      .login-box{ margin: 1.6rem auto; }
      .card-body{ padding: 20px 16px 22px; }
    }

    /* Reduced motion support */
    @media (prefers-reduced-motion: reduce){
      *{ animation: none !important; transition: none !important; }
    }
  </style>
</head>
<body class="hold-transition login-page">

  <!-- Decorative floating leaves -->
  <div class="leaf l1"></div>
  <div class="leaf l2"></div>
  <div class="leaf l3"></div>
  <div class="leaf l4"></div>

  <!-- Progress bar -->
  <div class="progress-top" id="progressTop" aria-hidden="true"></div>

  <div class="login-box">
    <div class="card card-outline card-primary<?php echo $hasError ? ' shake' : ''; ?>">
      <div class="card-header text-center">
        <a href="index.php" class="brand" aria-label="GroceryShop Home">
          <span class="logo"><i class="fas fa-leaf"></i></span>
          <span class="title"><b>Grocery</b>Shop</span>
        </a>
      </div>
      <div class="card-body">

        <?php if ($hasError): ?>
          <p class="login-box-msg text-danger" role="alert" aria-live="polite">
            <?php echo $_SESSION['error']; ?>
          </p>
          <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <div class="badge-accent">
          <i class="fas fa-shopping-basket"></i>
          Welcome back, Admin
        </div>

        <form action="login_check.php" method="post" novalidate>
          <div class="form-group">
            <label for="username" class="form-label">Email or Username</label>
            <div class="input-group mb-3">
              <input
                type="text"
                class="form-control"
                id="username"
                name="username"
                placeholder="Enter Username"
                autocomplete="username"
                required
                inputmode="email"
                aria-required="true"
              >
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-envelope"></span>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="password" class="form-label">Password</label>
            <div class="input-group mb-3">
              <input
                type="password"
                class="form-control"
                id="password"
                name="password"
                placeholder="••••••••"
                autocomplete="current-password"
                required
                aria-required="true"
              >
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-lock"></span>
                </div>
              </div>
            </div>
          </div>

          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">Remember me</label>
            </div>
            <!-- <a href="#" class="text-sm">Forgot password?</a> -->
          </div>

          <button type="submit" class="btn btn-primary btn-block">
            <i class="fas fa-sign-in-alt mr-1"></i> Sign In
          </button>
        </form>

        <!-- <div class="helper">
          <span>Need access?</span>
          <a href="#" aria-label="Contact support">Contact support</a>
        </div> -->

      </div>
    </div>
  </div>

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>

  <script>
    // Focus first field on load
    window.addEventListener('DOMContentLoaded', () => {
      const u = document.getElementById('username');
      if(u){ u.focus(); }

      // Button radial highlight follows cursor
      const btn = document.querySelector('.btn-primary');
      if(btn){
        btn.addEventListener('pointermove', e => {
          const r = btn.getBoundingClientRect();
          btn.style.setProperty('--x', `${e.clientX - r.left}px`);
          btn.style.setProperty('--y', `${e.clientY - r.top}px`);
        }, { passive:true });
      }

      // Lightweight validity hint (no logic change)
      document.querySelectorAll('.form-control').forEach(i=>{
        i.addEventListener('input', ()=>{
          i.classList.toggle('is-valid', i.value.trim().length>0);
        });
      });

      // Top progress bar on submit (does not block navigation)
      const form = document.querySelector('form[action="login_check.php"]');
      const bar = document.getElementById('progressTop');
      if(form && bar){
        form.addEventListener('submit', ()=>{
          bar.classList.add('active');
        }, { once:true });
      }
    });
  </script>
</body>
</html>
