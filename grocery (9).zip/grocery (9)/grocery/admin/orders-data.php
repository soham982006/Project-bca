<?php
require '../dbcon.php';

// Filter by status if provided
$status_filter = isset($_GET['status']) ? trim($_GET['status']) : "";
$statuses = ['Pending','Processing','Shipped','Delivered','Canceled'];

// Build SQL query safely
$sql = "
    SELECT o.oid, o.uid, o.status, o.date, o.total, u.name AS customer
    FROM ord o
    LEFT JOIN user u ON o.uid = u.uid
";
if ($status_filter !== "") {
    $safe_status = mysqli_real_escape_string($conn, $status_filter);
    $sql .= " WHERE o.status = '$safe_status'";
}
$sql .= " ORDER BY o.oid DESC";

$result = $conn->query($sql);
?>

<table id="ordersTable" class="table table-bordered table-striped">
  <thead>
    <tr>
      <th>Order ID</th>
      <th>Customer</th>
      <th>Total</th>
      <th>Status</th>
      <th>Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php if ($result && $result->num_rows > 0): ?>
    <?php while($row = $result->fetch_assoc()): 
      $rowClass = "status-" . strtolower($row['status']);
    ?>
      <tr class="<?= $rowClass ?>">
        <td>#<?= $row['oid'] ?></td>
        <td><?= htmlspecialchars($row['customer'] ?? 'Guest') ?></td>
        <td><i class="fa fa-rupee"></i> <?= number_format($row['total'], 2) ?></td>

        <td>
          <select class="form-control status-dropdown" data-id="<?= $row['oid'] ?>">
            <?php foreach ($statuses as $st): ?>
              <option value="<?= $st ?>" <?= $row['status'] == $st ? 'selected' : '' ?>>
                <?= $st ?>
              </option>
            <?php endforeach; ?>
          </select>
        </td>

        <td><?= date("d M Y, h:i A", strtotime($row['date'])) ?></td>

        <td>
          <a href="order-items.php?oid=<?= $row['oid'] ?>" 
             class="btn btn-sm btn-primary" 
             target="_blank" 
             title="View Order Items">
            <i class="fa fa-eye"></i> Show
          </a>
        </td>
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr><td colspan="6" class="text-center text-muted">No orders found.</td></tr>
  <?php endif; ?>
  </tbody>
</table>
