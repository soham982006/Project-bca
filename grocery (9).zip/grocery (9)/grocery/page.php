<?php
require 'dbcon.php';
$slug = isset($_GET['p']) ? strtolower(preg_replace('/[^a-z0-9\-]/', '', $_GET['p'])) : 'about';

$stmt = $conn->prepare("SELECT title, content FROM pages WHERE slug = ? AND status = 'Published' LIMIT 1");
$stmt->bind_param("s", $slug);
$stmt->execute();
$res = $stmt->get_result();
$page = $res->fetch_assoc();
$stmt->close();

$title = $page ? $page['title'] : 'Page Not Found';
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo htmlspecialchars($title); ?> | Grocery Store</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico">
</head>
<body>
<?php include 'header.php'; ?>
<div class="w3l_banner_nav_right">
  <div class="privacy about">
    <h3><?php echo htmlspecialchars($title); ?></h3>
    <div class="container" style="padding: 15px 0;">
      <?php if ($page): ?>
        <?php echo $page['content']; ?>
      <?php else: ?>
        <p>Sorry, the requested page was not found.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>
