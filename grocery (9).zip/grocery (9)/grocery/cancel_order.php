<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'dbcon.php';
header('Content-Type: application/json');

if (!isset($_SESSION['USER_ID'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$uid = intval($_SESSION['USER_ID']);
$oid = intval($_POST['oid'] ?? 0);

if ($oid <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid order ID']);
    exit;
}

// Check if order exists and belongs to user
$orderCheck = $conn->query("SELECT * FROM ord WHERE oid=$oid AND uid=$uid LIMIT 1");

if (!$orderCheck) {
    echo json_encode(['status' => 'error', 'message' => 'Database query error: '.$conn->error]);
    exit;
}

if ($orderCheck->num_rows == 0) {
    echo json_encode(['status' => 'error', 'message' => 'Order not found for this user']);
    exit;
}

$order = $orderCheck->fetch_assoc();
if (strtolower($order['status']) == 'canceled') {
    echo json_encode(['status' => 'error', 'message' => 'Order is already canceled']);
    exit;
}

if (strtolower($order['status']) == 'delivered') {
    echo json_encode(['status' => 'error', 'message' => 'Delivered orders cannot be canceled']);
    exit;
}

// Cancel order
$update = $conn->query("UPDATE ord SET status='Canceled' WHERE oid=$oid AND uid=$uid");

if ($update) {
    echo json_encode(['status' => 'success', 'message' => 'Order cancelled successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to cancel: '.$conn->error]);
}
?>
