<?php
include 'dbcon.php';
session_start();

if (isset($_GET['page']) && !empty($_GET['page'])) {
    $page = $_GET['page'] . '.php';
} else {
    $page = 'index.php';
}

if (isset($_SESSION['USER_ID']) && !empty($_SESSION['USER_ID'])) {
    header("Location: $page");
    exit;
}

$msg = '';

// ---------------- REGISTER ----------------
if (isset($_POST['submit'])) {
    $n  = $_POST['Name'];
    $m  = $_POST['Mobile'];
    $a1 = $_POST['Address'];
    $c  = $_POST['City'];
    $g  = $_POST['Gn'];
    $u  = $_POST['Username'];
    $p  = $_POST['Password'];

    $sql = "INSERT INTO user(name, mobile, address1, gender, username, password, status) 
            VALUES ('$n', '$m' ,'$a1','$g','$u','$p','Active')";

    if ($conn->query($sql)) {
        header('Location:login.php');
        exit;
    } else {
        echo 'Error: ' . $sql . '<br>' . $conn->error;
    }
}

// ---------------- LOGIN ----------------
if (isset($_POST['login'])) {
    $un = $_POST['User'];
    $pw = $_POST['Pass'];

    $sql = "SELECT uid, password, status FROM user WHERE username = '$un'";
    $result = $conn->query($sql);

    if ($result->num_rows) {
        $row = $result->fetch_assoc();

        // Check inactive users
        if ($row['status'] !== 'Active') {
            $msg = 'Your account is Inactive. Please contact admin.';
        } elseif ($row['password'] != $pw) {
            $msg = 'Wrong Password';
        } else {
            $_SESSION['USER_ID']   = $row['uid'];
            $_SESSION['USER_NAME'] = $un;
            header("Location: $page");
            exit;
        }
    } else {
        $msg = 'Wrong Username';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Grocery Store</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico" />

</head>
<body>
<?php include 'header.php' ?>
		
<div class="w3l_banner_nav_right">
    <!-- login -->
    <div class="w3_login">
        <h3>Sign In & Sign Up</h3>
        <div class="w3_login_module">
            <div class="module form-module">
                <div class="toggle"><i class="fa fa-times fa-pencil"></i>
                    <div class="tooltip">Click Me</div>
                </div>

                <!-- LOGIN FORM -->
                <div class="form">
                    <h2>Login to your account</h2>
                    <span class="text-danger"><?=$msg?></span>
                    <form action="" method="post">
                        <input type="text" name="User" placeholder="Username" required>
                        <input type="password" name="Pass" placeholder="Password" required>
                        <input type="submit" value="Login" name="login">
                    </form>
                    <div class="cta" style="margin-top: 18px">
                        <a href="f.php">Forgot your password?</a>
                    </div>
                </div>

                <!-- REGISTER FORM -->
                <div class="form">
                    <h2>Create an account</h2>
                    <span class="text-danger"><?=$msg?></span>
                    <form action="" method="post">
                        <input type="text" name="Name" placeholder="Name" required>
                        <input type="text" name="Mobile" placeholder="Mobile No" required pattern="[0-9]{10}" title="Must be 10 digits">
                        <input type="text" name="Address" placeholder="Address" required>
                        <input type="text" name="City" placeholder="City">
                        <label><input type="radio" name="Gn" value="Male" required> Male</label>
                        <label><input type="radio" name="Gn" value="Female" required> Female</label>
                        <input type="text" name="Username" placeholder="Username" required>
                        <input type="password" name="Password" placeholder="Password" required pattern="[a-z0-9]{6}" title="Password must be at least 6 characters">
                        <input type="submit" value="Register" name="submit">
                    </form>
                </div>
            </div>
        </div>

        <script>
            $('.toggle').click(function(){
              $(this).children('i').toggleClass('fa-pencil');
              $('.form').animate({
                height: "toggle",
                'padding-top': 'toggle',
                'padding-bottom': 'toggle',
                opacity: "toggle"
              }, "slow");
            });
        </script>
    </div>
    <!-- //login -->
</div>
<div class="clearfix"></div>

<?php include 'footer.php' ?>
</body>
</html>
