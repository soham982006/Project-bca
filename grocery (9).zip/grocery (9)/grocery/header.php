<?php
// header.php — final version (AJAX cart + conditional layout + clean title bar)
if (session_status() === PHP_SESSION_NONE) session_start();
require 'dbcon.php';

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

// Detect current page
$current_page = basename($_SERVER['PHP_SELF']);
$hide_cart_and_category = in_array($current_page, [
    'my_orders.php', 'checkout.php', 'invoice.php', 'order-cancel.php'
]);

// =================== AJAX CART HANDLING ===================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    $action = $_POST['action'] ?? 'load';
    $pid = intval($_POST['pid'] ?? 0);

    if ($action === 'add') {
        if ($pid <= 0 && !empty($_POST['item_name'])) {
            $name = mysqli_real_escape_string($conn, $_POST['item_name']);
            $res = mysqli_query($conn, "SELECT pid FROM product WHERE name='$name' LIMIT 1");
            if ($res && $r = $res->fetch_assoc()) $pid = intval($r['pid']);
        }

        if ($pid > 0) {
            $q = mysqli_query($conn, "SELECT name, price, discount, pic FROM product WHERE pid=$pid LIMIT 1");
            if ($row = mysqli_fetch_assoc($q)) {
                $price = floatval($row['price']);
                $disc = floatval($row['discount']);
                $final = $disc > 0 ? ($price - $price * $disc / 100) : $price;
                $pic = $row['pic'] ?: 'no-image.png';
                $_SESSION['cart'][$pid] = isset($_SESSION['cart'][$pid])
                    ? array_merge($_SESSION['cart'][$pid], [
                        'quantity' => $_SESSION['cart'][$pid]['quantity'] + 1
                    ])
                    : [
                        'pid' => $pid,
                        'name' => $row['name'],
                        'amount' => round($final, 2),
                        'original' => round($price, 2),
                        'discount' => round($disc, 2),
                        'quantity' => 1,
                        'pic' => $pic,
                        'subtotal' => round($final, 2)
                    ];
            }
        }
    }

    if ($pid && isset($_SESSION['cart'][$pid])) {
        if ($action === 'increase') $_SESSION['cart'][$pid]['quantity']++;
        if ($action === 'decrease') {
            if ($_SESSION['cart'][$pid]['quantity'] > 1) $_SESSION['cart'][$pid]['quantity']--;
            else unset($_SESSION['cart'][$pid]);
        }
        if ($action === 'remove') unset($_SESSION['cart'][$pid]);
    }

    foreach ($_SESSION['cart'] as &$it)
        $it['subtotal'] = round($it['amount'] * $it['quantity'], 2);
    unset($it);

    header('Content-Type: application/json');
    echo json_encode(array_values($_SESSION['cart']));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Grocery Store</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>

<style>
.inline-cart { position: relative; display: inline-block; }
.inline-cart-dropdown {
  position: absolute;
  right: 0; top: 110%;
  width: 350px;
  max-height: 400px;
  overflow-y: auto;
  background: #fff;
  border: 1px solid #ddd;
  box-shadow: 0 2px 8px rgba(0,0,0,.1);
  padding: 10px 15px;
  display: none;
  border-radius: 5px;
  z-index: 9999;
}
.inline-cart-item { border-bottom: 1px solid #eee; padding: 6px 0; }
.inline-cart-item:last-child { border-bottom: none; }
.inline-cart-remove { color: #d9534f; cursor: pointer; }
.inline-cart-remove:hover { text-decoration: underline; }
.price-line { font-size: 15px; color: #e74c3c; font-weight: 600; }
.price-line del { color: #888; margin-left: 6px; font-size: 13px; }
.inline-cart-item .btn.btn-default {
  background: #f8f8f8; border: 1px solid #ccc; color: #333; padding: 2px 6px;
}
.inline-cart-item span.qty-display {
  background: #f1f1f1; border: 1px solid #ccc; padding: 2px 8px; border-radius: 4px;
  min-width: 24px; display: inline-block; text-align: center;
}
.simple-titlebar {
  background: #28a745;
  color: #fff;
  text-align: center;
  padding: 14px 0;
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 20px;
  letter-spacing: 0.5px;
}
</style>

<script>
$(function(){
  $(document).on('click', '.inline-cart-toggle', function(e){
    e.stopPropagation(); $('.inline-cart-dropdown').fadeToggle(120);
  });
  $(document).on('click', function(e){
    if (!$(e.target).closest('.inline-cart-dropdown, .inline-cart-toggle').length)
      $('.inline-cart-dropdown').fadeOut(120);
  });

  $(document).on('submit', "form[action*='checkout.php']", function(e){
    e.preventDefault();
    let f = $(this).serializeArray();
    f.push({name:'ajax',value:1},{name:'action',value:'add'});
    $.post('header.php', f, function(cart){
      renderCart(cart); updateCount(cart);
      $('.inline-cart-dropdown').fadeIn(150);
      setTimeout(()=>$('.inline-cart-dropdown').fadeOut(400),1800);
    }, 'json');
  });

  $(document).on('click','.cart-plus',function(){
    $.post('header.php',{ajax:1,action:'increase',pid:$(this).data('id')},r=>{renderCart(r);updateCount(r);},'json');
  });
  $(document).on('click','.cart-minus',function(){
    $.post('header.php',{ajax:1,action:'decrease',pid:$(this).data('id')},r=>{renderCart(r);updateCount(r);},'json');
  });
  $(document).on('click','.cart-remove',function(){
    $.post('header.php',{ajax:1,action:'remove',pid:$(this).data('id')},r=>{renderCart(r);updateCount(r);},'json');
  });

  $(document).on('click','#inline-checkout-btn',()=>window.location='viewcart.php');
  $.post('header.php',{ajax:1,action:'load'},c=>{renderCart(c);updateCount(c);},'json');

  function renderCart(cart){
    let html='',total=0,totalQty=0;
    if(cart.length){
      cart.forEach(it=>{
        total+=it.subtotal; totalQty+=it.quantity;
        html+=`
        <div class="inline-cart-item row">
          <div class="col-xs-3"><img src="images/${it.pic}" width="50" height="50"></div>
          <div class="col-xs-9">
            <strong>${it.name}</strong>
            <div class="price-line">₹${it.amount.toFixed(2)} ${it.discount>0?`<del>₹${it.original.toFixed(2)}</del>`:''}</div>
            <div>
              <button class="btn btn-xs btn-default cart-minus" data-id="${it.pid}">−</button>
              <span class="qty-display">${it.quantity}</span>
              <button class="btn btn-xs btn-default cart-plus" data-id="${it.pid}">+</button>
              <span class="inline-cart-remove pull-right cart-remove" data-id="${it.pid}">
                <i class="fa fa-trash"></i>
              </span>
            </div>
            <small>Subtotal: ₹${it.subtotal.toFixed(2)}</small>
          </div>
        </div>`;
      });
      html+=`<hr><div class="text-right"><strong>Total: ₹${total.toFixed(2)}</strong><br>
      <button id="inline-checkout-btn" class="btn btn-success btn-sm" style="margin-top:5px;">Checkout</button></div>`;
    } else html='<p class="text-center text-muted">Your cart is empty</p>';
    $('.inline-cart-dropdown').html(html);
    $('#cart-count').text(totalQty);
  }
  function updateCount(cart){
    let q=0; if(cart&&cart.length){cart.forEach(it=>q+=parseInt(it.quantity));}
    $('#cart-count').text(q);
  }
});
</script>
</head>

<body>
<div class="agileits_header">
  <div class="w3l_offers"><a href="index.php">Grocery shopping</a></div>

  <?php if (!$hide_cart_and_category): ?>
  <div class="w3l_search">
    <form action="search.php" method="post">
      <input type="text" name="Product" value="Search a product..."
             onfocus="this.value='';" onblur="if(this.value==''){this.value='Search a product...';}" required="">
      <input type="submit" value=" ">
    </form>
  </div>

  <div class="product_list_header inline-cart">
    <button type="button" class="btn btn-primary inline-cart-toggle">
      <i class="fa fa-shopping-cart"></i> Cart <span class="badge" id="cart-count">0</span>
    </button>
    <div class="inline-cart-dropdown"><p class="text-center text-muted">Loading...</p></div>
  </div>
  <?php endif; ?>

  <div class="w3l_header_right">
    <ul><li class="dropdown profile_details_drop">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <i class="fa fa-user" aria-hidden="true"></i> <span class="caret"></span>
      </a>
      <div class="mega-dropdown-menu"><div class="w3ls_vegetables"><ul class="dropdown-menu drp-mnu">
        <?php
        if (isset($_SESSION['USER_ID'])) {
          echo '<li><a href="#">'.ucwords($_SESSION['USER_NAME']).'</a></li>';
          echo '<li><a href="logout.php">Logout</a></li>';
        } else echo '<li><a href="login.php">Login/Signup</a></li>';
        ?>
      </ul></div></div></li></ul>
  </div>

  <div class="w3l_header_right1"><h2><a href="mail.php">Contact Us</a></h2></div>
  <div class="clearfix"></div>
</div>

<?php if ($hide_cart_and_category): ?>
  <!-- Simple title bar for pages like My Orders / Checkout / Invoice -->
  <div class="simple-titlebar">
    <?php
      $title = [
        'my_orders.php' => 'My Orders',
        'checkout.php' => 'Checkout',
        'invoice.php' => 'Invoice',
        'order-cancel.php' => 'Order Cancellation'
      ][$current_page] ?? 'Grocery Shop';
      echo htmlspecialchars($title);
    ?>
  </div>
<?php else: ?>
  <!-- Normal navigation and categories -->
  <div class="logo_products">
    <div class="container">
      <div class="w3ls_logo_products_left"><h1><a href="index.php"><span>Grocery</span> Shop</a></h1></div>
      <div class="w3ls_logo_products_left1">
        <ul class="special_items">
          <li><a href="about.php">About Us</a> &nbsp;/&nbsp;</li>
          <li><a href="services.php">Services</a> &nbsp;/&nbsp;</li>
          <li><a href="privacy.php">Privacy Policy</a></li>
          <?php if (isset($_SESSION['USER_ID'])) echo '<li>&nbsp;/&nbsp;<a href="my_orders.php">Orders</a></li>'; ?>
        </ul>
      </div>
      <div class="w3ls_logo_products_left1">
        <ul class="phone_email">
          <li><i class="fa fa-phone"></i> (+91) 6355161877</li>
          <li><i class="fa fa-envelope-o"></i> store@grocery.com</li>
        </ul>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>

  <div class="products-breadcrumb">
    <div class="container"><ul><li><i class="fa fa-home"></i><a href="index.php">Home</a></li></ul></div>
  </div>

  <div class="banner">
    <div class="w3l_banner_nav_left">
      <nav class="navbar nav_bottom">
        <div class="navbar-header nav_2">
          <button type="button" class="navbar-toggle collapsed navbar-toggle1"
                  data-toggle="collapse" data-target="#bs-megadropdown-tabs">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
          <ul class="nav navbar-nav nav_1">
            <?php
            $q1=mysqli_query($conn,"SELECT * FROM category WHERE parent_id=0");
            while($c=mysqli_fetch_assoc($q1)){
              $q2=mysqli_query($conn,"SELECT * FROM category WHERE parent_id=".$c['cid']);
              if(mysqli_num_rows($q2)>0){
                echo '<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.ucwords($c['name']).' <span class="caret"></span></a>';
                echo '<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu"><div class="w3ls_vegetables"><ul>';
                while($s=mysqli_fetch_assoc($q2)){
                  echo '<li><a href="products.php?id='.$s['cid'].'">'.ucwords($s['name']).'</a></li>';
                }
                echo '</ul></div></div></li>';
              } else {
                echo '<li><a href="products.php?id='.$c['cid'].'">'.ucwords($c['name']).'</a></li>';
              }
            }
            ?>
          </ul>
        </div>
      </nav>
    </div>
  </div>
<?php endif; ?>
