<!-- ```php -->
<?php 
require 'dbcon.php';
require 'header.php';

$title = "Search Results";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo $title; ?> | Grocery Store</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico" />

</head>
<body>

<div class="w3l_banner_nav_right">
  <div class="w3l_banner_nav_right_banner4">
    <h3>Search Results<span class="blink_me"></span></h3>
  </div>

  <div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
    <h3><?php echo $title; ?></h3>
    <div class="w3ls_w3l_banner_nav_right_grid1">

      <?php
      if (isset($_POST['submit'])) {
          $p = mysqli_real_escape_string($conn, $_POST['Product']);

          // search product name OR category name
          $sql = "SELECT p.pid, p.name, p.price, p.discount, p.weight, p.pic, c.name AS category 
                  FROM product p
                  JOIN category c ON p.cid = c.cid
                  WHERE p.name LIKE '%$p%' OR c.name LIKE '%$p%'";
          $result = mysqli_query($conn, $sql);

          if ($result && $result->num_rows) {
              while ($product = $result->fetch_assoc()) {
                  $pid = $product['pid'];
                  $name = $product['name'];
                  $weight = trim($product['weight'], '()');

                  // Normalize image path
                  $picFile = ltrim(str_replace("images/", "", $product['pic']), '/');
                  $picPath = "images/" . $picFile;
                  if (empty($picFile) || !file_exists($picPath)) {
                      $picPath = "images/no-image.png";
                  }

                  $price = $product['price'];
                  $discount = $product['discount'];
                  $discount_money = $price * ($discount / 100);
                  $new_price = $discount == 0
                      ? $price
                      : $price * (1 - ($discount / 100));
                  ?>
                  <div class="col-md-3 top_brand_left" style="margin-bottom:15px">
                      <div class="hover14 column">
                          <div class="agile_top_brand_left_grid">
                              <div class="tag">
                                  <img src="images/tag.png" alt="" class="img-responsive">
                              </div>
                              <div class="agile_top_brand_left_grid1">
                                  <figure>
                                      <div class="snipcart-item block">
                                          <div class="snipcart-thumb">
                                              <a href="#">
                                                  <img title="<?php echo htmlspecialchars($name); ?>" 
                                                       alt="<?php echo htmlspecialchars($name); ?>" 
                                                       src="<?php echo $picPath; ?>" 
                                                       width="140">
                                              </a>
                                              <p><?php echo $name . ($weight ? " ($weight)" : ''); ?></p>
                                              <small style="color:#777;">Category: <?php echo $product['category']; ?></small>
                                              <h4>
                                                  <i class="fa fa-rupee"></i> <?php echo $new_price; ?>
                                                  <span>
                                                      <?php if ($discount) { ?>
                                                          <i class="fa fa-rupee"></i> <?php echo $price; ?>
                                                      <?php } ?>
                                                  </span>
                                              </h4>
                                          </div>
                                          <div class="snipcart-details top_brand_home_details">
                                              <form action="checkout.php" method="post">
                                                  <fieldset>
                                                      <input type="hidden" name="cmd" value="_cart" />
                                                      <input type="hidden" name="add" value="1" />
                                                      <input type="hidden" name="business" value="" />
                                                      <input type="hidden" name="item_name" value="<?php echo $name; ?>" />
                                                      <input type="hidden" name="amount" value="<?php echo $price; ?>" />
                                                      <input type="hidden" name="discount_amount" value="<?php echo $discount_money; ?>" />
                                                      <input type="hidden" name="currency_code" value="INR" />
                                                      <input type="hidden" name="return" value="" />
                                                      <input type="hidden" name="cancel_return" value="" />
                                                      <input type="submit" name="submit" value="Add to cart" class="button" />
                                                  </fieldset>
                                              </form>
                                          </div>
                                      </div>
                                  </figure>
                              </div>
                          </div>
                      </div>
                  </div>
                  <?php
              }
          } else {
              echo "<p>No products found for <b>".htmlspecialchars($p)."</b>.</p>";
          }
      }
      ?>
      <div class="clearfix"></div>
    </div>
  </div>
</div>
<div class="clearfix"></div>

<?php include 'footer.php'; ?>
</body>
</html>
```
