<?php
session_start();
require 'dbcon.php';

// If cart is empty and no POST, redirect
if (!isset($_SESSION['products']) || empty($_SESSION['products'])) {
    if (empty($_POST)) {
        header('Location: index.php');
        exit;
    }
    foreach ($_POST as $key => $val) {
        $array = explode('_', $key);

        if (count($array) > 1) {
            $i = array_pop($array);
        } else {
            $i = $array[0];
        }

        $key = implode('_', $array);

        if (is_numeric($i)) {
            $products[$i][$key] = $val;
        } else {
            $cart[$key] = $val;
        }
    }

    $total = $cart['total'];
    $_SESSION['products'] = $products;
    $_SESSION['total'] = $total;
} else {
    $products = $_SESSION['products'];
    $total = $_SESSION['total'];
}

// Save order if user is logged in
$orderPlaced = false; // flag to show success message only once
if (isset($_SESSION['USER_ID']) && !empty($_SESSION['USER_ID'])) {
    $uid = $_SESSION['USER_ID'];
    $total = $_SESSION['total'];

    // Save order in ord
    $query = "INSERT INTO ord(uid, total) VALUES ($uid, $total)";
    $result = $conn->query($query);
    if (!$result) {
        echo 'Error: '.$conn->error;
        exit;
    }

    // Get last inserted order ID
    $oid = $conn->query('SELECT LAST_INSERT_ID();')->fetch_assoc()['LAST_INSERT_ID()'];

    // Save order items
    foreach ($products as $pid => $product) {
        $query = "INSERT INTO order_items(oid, pid, quantity, amount, subtotal) 
                  VALUES ($oid, $pid, $product[quantity], $product[amount], $product[subtotal])";
        $result = $conn->query($query);
        if (!$result) {
            echo 'Error: '.$conn->error;
            exit;
        }
    }

    // Save payment (COD only)
    $query = "INSERT INTO payment(total_amount, payment_type, oid, uid) 
              VALUES ($total, 'COD', $oid, $uid)";
    $result = $conn->query($query);
    if (!$result) {
        echo 'Error: '.$conn->error;
        exit;
    }

    // ✅ Clear cart after order placed
    unset($_SESSION['products']);
    unset($_SESSION['total']);
    $orderPlaced = true;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout | Grocery Store</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico" />

    <?php include 'header.php'; ?>
</head>
<body>

<!-- banner -->
<div class="banner">
    <div class="w3l_banner_nav_right">
        <!-- payment -->
        <div class="privacy about">
            <h3>Pay<span>ment</span></h3>
            <div class="checkout-right">
                <?php if (!isset($_SESSION['USER_ID']) || empty($_SESSION['USER_ID'])) { ?>
                    <div class="col-md-12 address_form_agile">
                        <section class="creditly-wrapper wthree, w3_agileits_wrapper" style="margin-top: 35px">
                            <div class="information-wrapper">
                                <a href="login.php?page=checkout">
                                    <button class="submit check_out btn-block">Login To Continue</button>
                                </a>
                            </div>
                        </section>
                    </div>
                    <div class="clearfix"></div>
                <?php } elseif ($orderPlaced) { ?>
                    <div class="col-md-12 address_form_agile">
                        <section class="creditly-wrapper wthree, w3_agileits_wrapper" style="margin-top: 35px">
                            <div class="information-wrapper">
                                <button class="submit check_out btn-block">✅ Your order has been placed successfully</button>
                            </div>
                        </section>
                    </div>
                    <div class="clearfix"></div>

                    <!-- ✅ Only COD option -->
                    <div class="cod-box" style="margin-top:20px;">
                        <h4>Payment Method: Cash on Delivery</h4>
                        <p>You selected Cash on Delivery.  
                        Please keep the cash ready at the time of delivery.</p>
                    </div>
                <?php } ?>
            </div>
        </div>
        <!-- //payment -->
    </div>
    <div class="clearfix"></div>
</div>
<!-- //banner -->

<!-- footer -->
<?php include 'footer.php'; ?>
<!-- //footer -->

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</body>
</html>
