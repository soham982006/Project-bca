<?php
ob_start(); // Prevent "headers already sent" warnings
session_start();
require 'dbcon.php';

// ✅ Check login BEFORE including header (avoids output before header redirect)
if (!isset($_SESSION['USER_ID'])) {
    header("Location: login.php");
    exit;
}

include 'header.php'; // safe to include after redirect check

// Ensure cart exists
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
$uid = intval($_SESSION['USER_ID']);
$cart = $_SESSION['cart'];

// =================== PLACE ORDER ===================
if (isset($_POST['place_order'])) {
    $address = trim($_POST['address'] ?? '');
    $payment_type = 'COD'; // Only Cash on Delivery

    // --- Prevent duplicate order submissions ---
    if (isset($_SESSION['last_order_token']) && $_SESSION['last_order_token'] === $_POST['order_token']) {
        header("Location: my_orders.php");
        exit;
    }

    if (empty($address)) {
        $order_error = "Please enter a delivery address.";
    } elseif (empty($cart)) {
        $order_error = "Your cart is empty.";
    } else {
        $total = 0;
        $items = [];

        // Calculate totals
        foreach ($cart as $pid => $c) {
            $pid = intval($pid);
            $res = $conn->query("SELECT price, discount FROM product WHERE pid=$pid LIMIT 1");
            if ($row = $res->fetch_assoc()) {
                $price = floatval($row['price']);
                $discount = floatval($row['discount']);
                $final = ($discount > 0) ? ($price - ($price * $discount / 100)) : $price;
                $qty = intval($c['quantity']);
                $subtotal = $final * $qty;
                $total += $subtotal;
                $items[] = ['pid'=>$pid, 'qty'=>$qty, 'amount'=>$final, 'subtotal'=>$subtotal];
            }
        }

        // Insert order (ensure `address` column exists in `ord` table)
        $stmt = $conn->prepare("INSERT INTO ord (uid, total, address, status) VALUES (?, ?, ?, 'Pending')");
        $stmt->bind_param("ids", $uid, $total, $address);

        if ($stmt->execute()) {
            $oid = $conn->insert_id;

            // Save the token to prevent resubmission
            $_SESSION['last_order_token'] = $_POST['order_token'];

            // Insert order items
            $stmt2 = $conn->prepare("INSERT INTO order_items (oid, pid, quantity, amount, subtotal) VALUES (?, ?, ?, ?, ?)");
            foreach ($items as $it) {
                $stmt2->bind_param("iiidd", $oid, $it['pid'], $it['qty'], $it['amount'], $it['subtotal']);
                $stmt2->execute();
            }

            // Save payment (only COD)
            $stmt3 = $conn->prepare("INSERT INTO payment (oid, uid, total_amount, payment_type) VALUES (?, ?, ?, ?)");
            $stmt3->bind_param("iids", $oid, $uid, $total, $payment_type);
            $stmt3->execute();

            // Clear cart and redirect
            $_SESSION['cart'] = [];
            header("Location: my_orders.php");
            exit;
        } else {
            $order_error = "Something went wrong. Try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>My Cart | Grocery Shop</title>
<style>
body { background: #f8f9fa; }
.checkout-right h4 { margin-bottom: 20px; font-weight: 600; }
.timetable_sub { width: 100%; border-collapse: collapse; background: #fff; }
.timetable_sub th, .timetable_sub td {
  padding: 12px;
  border: 1px solid #ddd;
  text-align: center;
  vertical-align: middle;
}
.timetable_sub img { width: 70px; border-radius: 6px; }
.quantity-select .entry { display:inline-block; padding:4px 10px; border:1px solid #ccc; margin:0 2px; cursor:pointer; border-radius:4px; }
.quantity-select .value { min-width:30px; background:#f9f9f9; display:inline-block; border-radius:4px; }
.close1 { background:#d9534f; color:#fff; font-weight:bold; border-radius:50%; padding:2px 6px; cursor:pointer; }
.checkout-left-basket ul { list-style:none; padding:0; }
.checkout-left-basket li { margin:8px 0; }
.address_form_agile { margin-top:20px; }
.address_form_agile textarea {
  width:100%; resize:none; border-radius:6px; border:1px solid #ccc; padding:10px;
}
.btn { padding:8px 16px; border:none; border-radius:4px; cursor:pointer; }
.btn-success { background:#5cb85c; color:#fff; }
.btn-default { background:#f0f0f0; border:1px solid #ccc; }
.btn-success:hover { background:#449d44; }
</style>
</head>
<body>
<div class="w3l_banner_nav_right">
  <div class="privacy about">
    <h3>My <span>Cart</span></h3>

    <?php if (!empty($order_error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($order_error) ?></div>
    <?php endif; ?>

    <div class="checkout-right">
      <h4>Your shopping cart contains: <?= count($cart) ?> Products</h4>
      <table class="timetable_sub">
        <thead>
          <tr>
            <th>#</th>
            <th>Product</th>
            <th>Name</th>
            <th>Rate</th>
            <th>Quantity</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $i=1; $total=0;
        foreach ($cart as $pid=>$c):
          $pid=intval($pid);
          $res=$conn->query("SELECT * FROM product WHERE pid=$pid");
          if(!$res->num_rows) continue;
          $p=$res->fetch_assoc();
          $price=$p['price']; $discount=$p['discount'];
          $final=($discount>0)?($price-($price*$discount/100)):$price;
          $qty=$c['quantity'];
          $sub=$final*$qty; $total+=$sub;
        ?>
          <tr>
            <td><?= $i++ ?></td>
            <td><img src="images/<?= htmlspecialchars($p['pic']) ?>" alt="<?= htmlspecialchars($p['name']) ?>"></td>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td>₹<?= number_format($final,2) ?></td>
            <td><?= $qty ?></td>
            <td>₹<?= number_format($sub,2) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="checkout-left" style="margin-top:30px;">
      <div class="col-md-4 checkout-left-basket">
        <ul>
          <li>Delivery Charges <i>-</i> <span class="text-primary">Free</span></li>
          <li><hr></li>
          <li style="font-weight:bold;">Total ₹<?= number_format($total,2) ?></li>
        </ul>
      </div>

      <div class="col-md-8 address_form_agile">
        <form method="POST">
          <!-- Unique order token -->
          <input type="hidden" name="order_token" value="<?php echo md5(uniqid(mt_rand(), true)); ?>">

          <label><strong>Delivery Address:</strong></label>
          <textarea name="address" rows="3" required></textarea>

          <label style="margin-top:10px;"><strong>Payment Method:</strong></label>
          <p><input type="radio" name="payment_type" value="COD" checked> Cash on Delivery (COD)</p>

          <button type="submit" name="place_order" class="btn btn-success">Place Order</button>
          <a href="products.php" class="btn btn-default">Continue Shopping</a>
        </form>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</div>

<div class="clearfix"></div>
<?php include 'footer.php'; ?>
</body>
</html>
