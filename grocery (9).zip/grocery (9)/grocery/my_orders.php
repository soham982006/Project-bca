<?php
session_start();
require 'dbcon.php';
include 'header.php';

if (!isset($_SESSION['USER_ID'])) {
    header("Location: login.php");
    exit;
}

$uid = intval($_SESSION['USER_ID']);
$orders = $conn->query("SELECT * FROM ord WHERE uid=$uid ORDER BY date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Orders | Grocery Shop</title>
<style>
body { background: #f8f9fa; }
.order-card {
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 25px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.05);
}
.order-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #eee;
  padding-bottom: 10px;
  margin-bottom: 15px;
}
.order-header h4 { margin: 0; font-weight: 600; }
.order-status {
  padding: 6px 12px;
  border-radius: 15px;
  font-size: 13px;
  color: #fff;
}
.status-Pending { background: #f0ad4e; }
.status-Processing { background: #5bc0de; }
.status-Shipped { background: #0275d8; }
.status-Delivered { background: #5cb85c; }
.status-Canceled { background: #d9534f; }

.product-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #f1f1f1;
  padding: 10px 0;
}
.product-info { display: flex; align-items: center; }
.product-info img {
  width: 60px;
  height: 60px;
  object-fit: contain;
  margin-right: 12px;
  border-radius: 6px;
  border: 1px solid #eee;
}
.product-name { font-weight: 600; font-size: 15px; }
.product-qty { color: #777; font-size: 13px; }
.product-price { font-weight: 600; font-size: 14px; color: #333; }

.order-details {
  background: #f9f9f9;
  border-radius: 8px;
  padding: 10px 15px;
  font-size: 14px;
  margin-top: 10px;
}
.order-details strong { color: #333; }
.order-total {
  text-align: right;
  font-size: 16px;
  font-weight: 600;
  margin-top: 10px;
}
.no-orders {
  text-align: center;
  font-size: 18px;
  color: #777;
  margin-top: 40px;
}
.action-buttons {
  margin-top: 10px;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
.btn-action {
  border: none;
  padding: 6px 12px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 13px;
}
.btn-cancel { background: #d9534f; color: #fff; }
.btn-cancel:hover { background: #c9302c; }
</style>
</head>

<body>
<div class="container" style="margin-top:40px; margin-bottom:50px;">
  <h2 class="text-center mb-4">My Orders</h2>

  <?php if ($orders && $orders->num_rows > 0): ?>
    <?php while ($order = $orders->fetch_assoc()): ?>
      <?php
      $oid = $order['oid'];

      // Fetch payment info
      $payment = $conn->query("SELECT payment_type FROM payment WHERE oid=$oid LIMIT 1")->fetch_assoc();
      $payment_type = $payment['payment_type'] ?? 'COD';
      $address = $order['address'] ?? 'Not provided';
      ?>

      <div class="order-card" id="order_<?= $oid ?>">
        <div class="order-header">
          <h4>Order #<?= $order['oid'] ?></h4>
          <span class="order-status status-<?= htmlspecialchars($order['status']) ?>">
            <?= htmlspecialchars($order['status']) ?>
          </span>
        </div>

        <p style="color:#777;">Placed on <?= date("d M Y, h:i A", strtotime($order['date'])) ?></p>

        <div class="order-details">
          <p><strong>Delivery Address:</strong> <?= htmlspecialchars($address) ?></p>
          <p><strong>Payment Method:</strong> <?= htmlspecialchars($payment_type) ?></p>
        </div>

        <?php
        $items = $conn->query("
          SELECT oi.*, p.name, p.pic 
          FROM order_items oi 
          JOIN product p ON oi.pid = p.pid 
          WHERE oi.oid = $oid
        ");
        while ($item = $items->fetch_assoc()):
        ?>
          <div class="product-item">
            <div class="product-info">
              <img src="images/<?= htmlspecialchars($item['pic']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
              <div>
                <div class="product-name"><?= htmlspecialchars($item['name']) ?></div>
                <div class="product-qty">Qty: <?= $item['quantity'] ?></div>
              </div>
            </div>
            <div class="product-price">₹<?= number_format($item['subtotal'], 2) ?></div>
          </div>
        <?php endwhile; ?>

        <div class="order-total">
          Total: ₹<?= number_format($order['total'], 2) ?>
        </div>

        <div class="action-buttons">
          <?php if (strtolower($order['status']) == 'pending'): ?>
            <button class="btn-action btn-cancel" onclick="cancelOrder(<?= $oid ?>)">Cancel Order</button>
          <?php endif; ?>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="no-orders">You have not placed any orders yet.</div>
  <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

<script src="js/jquery-1.11.1.min.js"></script>
<script>
function cancelOrder(oid){
  if(!confirm("Are you sure you want to cancel this order?")) return;

  $.ajax({
    url: "cancel_order.php",
    type: "POST",
    dataType: "json",
    data: { oid: oid },
    success: function(res){
      if(res.status === "success"){
          alert("Order cancelled successfully!");
          $("#order_"+oid).find(".order-status")
            .removeClass()
            .addClass("order-status status-Canceled")
            .text("Canceled");
          $("#order_"+oid).find(".btn-cancel").remove();
      } else {
          alert("Error: " + res.message);
      }
    },
    error: function(xhr){
      alert("Something went wrong:\n" + xhr.responseText);
    }
  });
}
</script>
</body>
</html>
