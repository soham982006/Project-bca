<?php
session_start();

// Check if pid is passed
if (isset($_GET['pid'])) {
    $pid = $_GET['pid'];

    // If the product exists in the cart, remove it
    if (isset($_SESSION['cart'][$pid])) {
        unset($_SESSION['cart'][$pid]);
    }
}

// Redirect back to cart
header("Location: cart.php");
exit;
?>
