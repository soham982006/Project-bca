<?php
require 'dbcon.php';
include 'header.php'; // ✅ includes responsive header with cart + My Orders logic
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Grocery Store | Privacy Policy</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico" />

  <!-- CSS already included in header.php -->
</head>

<body>

  <div class="w3l_banner_nav_right">
    <!-- ===== PRIVACY POLICY SECTION ===== -->
    <div class="privacy">
      <div class="privacy1">
        <h3>Privacy Policy</h3>
        <div class="banner-bottom-grid1 privacy1-grid">
          <ul>
            <li><i class="glyphicon glyphicon-user" aria-hidden="true"></i></li>
            <li>
              Profile 
              <span>We respect your privacy and are committed to protecting your personal information. Your account details and order history are stored securely and never shared with third parties except as required to provide our services.</span>
            </li>
          </ul>

          <ul>
            <li><i class="glyphicon glyphicon-search" aria-hidden="true"></i></li>
            <li>
              Search 
              <span>When you browse or search products, we may collect anonymous data to improve your shopping experience. We never track sensitive personal activity without your consent.</span>
            </li>
          </ul>

          <ul>
            <li><i class="glyphicon glyphicon-paste" aria-hidden="true"></i></li>
            <li>
              Orders & Payments 
              <span>All payment transactions are encrypted and processed through secure gateways. We do not store your card details on our servers.</span>
            </li>
          </ul>

          <ul>
            <li><i class="glyphicon glyphicon-qrcode" aria-hidden="true"></i></li>
            <li>
              Applications 
              <span>If you use our mobile app or other digital services, we may collect limited technical information (like device type, browser, IP address) only to improve functionality and performance.</span>
            </li>
          </ul>
        </div>
      </div>

      <!-- ===== TERMS OF USE ===== -->
      <div class="privacy1">
        <h3>Terms of Use</h3>
        <div class="banner-bottom-grid1 privacy2-grid">
          <div class="privacy2-grid1">
            <h4>Welcome to Grocery Store</h4>
            <p>By accessing or using our website, you agree to comply with the following terms and conditions. Please read them carefully before placing any orders.</p>

            <div class="privacy2-grid1-sub">
              <h5>1. Use of Website</h5>
              <p>You agree to use this website only for lawful purposes and in a way that does not infringe upon the rights of others or restrict their use and enjoyment.</p>
            </div>

            <div class="privacy2-grid1-sub">
              <h5>2. Product Information</h5>
              <p>We strive to keep all product details, images, and prices accurate. However, errors may occur, and we reserve the right to correct them without prior notice.</p>
            </div>

            <div class="privacy2-grid1-sub">
              <h5>3. Orders & Payments</h5>
              <p>All orders are subject to acceptance and product availability. Payments must be completed using our secure payment options before delivery.</p>
            </div>

            <div class="privacy2-grid1-sub">
              <h5>4. Delivery & Returns</h5>
              <p>We ensure timely delivery of your orders. If products are damaged or incorrect, customers may request a return or replacement within the allowed period.</p>
            </div>

            <div class="privacy2-grid1-sub">
              <h5>5. Limitation of Liability</h5>
              <p>We are not liable for indirect, incidental, or consequential damages arising from the use of our website or services. Our liability is limited to the value of the product purchased.</p>
            </div>

            <div class="privacy2-grid1-sub">
              <h5>6. Changes to Policy</h5>
              <p>We may update this Privacy Policy and Terms of Use from time to time. Continued use of our services constitutes acceptance of these changes.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- //privacy -->
  </div>

  <div class="clearfix"></div>

  <!-- ===== FOOTER ===== -->
  <?php include 'footer.php'; ?>

  <!-- ===== PAGE CUSTOM STYLING ===== -->
  <style>
    .privacy {
      padding: 20px;
      font-family: 'Open Sans', sans-serif;
    }

    .privacy h3 {
      font-size: 26px;
      font-weight: 700;
      color: #333;
      margin-bottom: 20px;
    }

    .privacy1-grid ul {
      list-style: none;
      padding: 0;
      display: flex;
      align-items: flex-start;
      margin-bottom: 15px;
    }

    .privacy1-grid ul li:first-child {
      margin-right: 15px;
      font-size: 22px;
      color: #8dc63f;
    }

    .privacy1-grid ul li span {
      display: block;
      font-size: 15px;
      color: #555;
      margin-top: 5px;
    }

    .privacy2-grid1-sub {
      margin-bottom: 20px;
    }

    .privacy2-grid1-sub h5 {
      color: #8dc63f;
      font-weight: 600;
      font-size: 18px;
    }

    .privacy2-grid1-sub p {
      font-size: 15px;
      color: #444;
      line-height: 1.8;
      margin-top: 8px;
    }

    @media (max-width: 768px) {
      .privacy1-grid ul {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>

</body>
</html>
