<?php
require 'dbcon.php';
include 'header.php'; // ✅ new responsive header with My Orders + cart logic
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Grocery Store | Services</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico" />

  <!-- Existing CSS already included in header.php (Bootstrap, style.css, font-awesome) -->
</head>

<body>
  <div class="w3l_banner_nav_right">
    <!-- ===== SERVICES SECTION ===== -->
    <div class="services">
      <h3>Our Services</h3>

      <!-- ✅ Service Intro Section -->
      <div class="w3ls_service_grids">
        <div class="col-md-6 w3ls_service_grid_left">
          <h4>Fast & Reliable Delivery</h4>
          <p>
            We provide same-day and next-day delivery across multiple locations,
            ensuring your groceries reach you fresh and on time.
            Our logistics team is trained to handle all orders with care, so you never have to worry about delays.
          </p>

          <h4>Wide Product Range</h4>
          <p>
            From fresh vegetables, fruits, and dairy to packaged foods, household essentials, and personal care products,
            we offer everything your family needs under one roof.
          </p>
        </div>

        <div class="col-md-6 w3ls_service_grid_right">
          <div class="row">
            <div class="col-md-4 w3ls_service_grid_right_1">
              <img src="images/18.jpg" alt="Service 1" class="img-responsive" />
            </div>
            <div class="col-md-4 w3ls_service_grid_right_1">
              <img src="images/19.jpg" alt="Service 2" class="img-responsive" />
            </div>
            <div class="col-md-4 w3ls_service_grid_right_1">
              <img src="images/20.jpg" alt="Service 3" class="img-responsive" />
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
      </div>

      <!-- ✅ Service Highlights Section -->
      <div class="w3ls_service_grids1">
        <div class="col-md-6 w3ls_service_grids1_left">
          <img src="images/4.jpg" alt=" " class="img-responsive img-rounded" />
        </div>

        <div class="col-md-6 w3ls_service_grids1_right">
          <ul class="list-unstyled">
            <li><i class="fa fa-long-arrow-right"></i> Fresh & Quality Products – We guarantee freshness and quality in every order.</li>
            <li><i class="fa fa-long-arrow-right"></i> 24/7 Customer Support – Our support team is always available for assistance.</li>
            <li><i class="fa fa-long-arrow-right"></i> Secure Payments – Multiple payment options with SSL encryption for safety.</li>
            <li><i class="fa fa-long-arrow-right"></i> Exclusive Deals – Daily discounts and seasonal offers for our valued customers.</li>
            <li><i class="fa fa-long-arrow-right"></i> Easy Returns – Hassle-free returns and replacements if you’re not satisfied.</li>
            <li><i class="fa fa-long-arrow-right"></i> Trusted Service – Thousands of happy customers rely on us for their daily needs.</li>
          </ul>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- //services -->
  </div>

  <div class="clearfix"></div>

  <!-- ===== SERVICES COUNTER SECTION ===== -->
  <div class="services-bottom">
    <div class="container">
      <div class="col-md-3 about_counter_left">
        <i class="glyphicon glyphicon-user" aria-hidden="true"></i>
        <p class="counter">15545</p>
        <h3>Happy Customers</h3>
      </div>
      <div class="col-md-3 about_counter_left">
        <i class="glyphicon glyphicon-piggy-bank" aria-hidden="true"></i>
        <p class="counter">79956</p>
        <h3>Orders Delivered</h3>
      </div>
      <div class="col-md-3 about_counter_left">
        <i class="glyphicon glyphicon-export" aria-hidden="true"></i>
        <p class="counter">1200</p>
        <h3>Products Available</h3>
      </div>
      <div class="col-md-3 about_counter_left">
        <i class="glyphicon glyphicon-bullhorn" aria-hidden="true"></i>
        <p class="counter">500</p>
        <h3>Exclusive Deals</h3>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>

  <!-- ===== FOOTER ===== -->
  <?php include 'footer.php'; ?>

  <!-- ===== COUNTER SCRIPTS ===== -->
  <script src="js/waypoints.min.js"></script>
  <script src="js/counterup.min.js"></script>
  <script>
    jQuery(document).ready(function ($) {
      $('.counter').counterUp({
        delay: 10,
        time: 1000
      });
    });
  </script>

  <!-- ===== PAGE STYLE FIX ===== -->
  <style>
    .w3ls_service_grids {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      margin-bottom: 40px;
    }

    .w3ls_service_grid_left,
    .w3ls_service_grid_right {
      float: none;
    }

    .w3ls_service_grid_right .row {
      display: flex;
      justify-content: center;
      gap: 15px;
    }

    .w3ls_service_grid_right img {
      max-width: 100%;
      border-radius: 10px;
      box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);
    }

    @media (max-width: 768px) {
      .w3ls_service_grids {
        flex-direction: column;
        text-align: center;
      }

      .w3ls_service_grid_right .row {
        flex-direction: row;
        flex-wrap: wrap;
      }

      .w3ls_service_grid_right .col-md-4 {
        flex: 1 1 45%;
        margin-bottom: 15px;
      }
    }
  </style>
</body>
</html>
