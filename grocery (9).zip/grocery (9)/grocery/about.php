<?php
require 'dbcon.php';
include 'header.php'; // ✅ new responsive header with cart + My Orders + alignment fix
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Grocery Store | About Us</title>
  <link rel="icon" type="image/x-icon" href="images/generated-image.ico" />

  <!-- CSS already included via header.php (bootstrap, style.css, font-awesome) -->
</head>

<body>

  <div class="w3l_banner_nav_right">
    <!-- ===== ABOUT SECTION ===== -->
    <div class="privacy about">
      <h3>About Us</h3>

      <p class="about-intro">
        Welcome to <strong>Fresh & Smart Grocery</strong>, India’s most convenient online grocery store.  
        We make your shopping experience simple and stress-free. Forget the hassle of crowded markets and long queues — 
        now shop from the comfort of your home, office, or even on the move.  
      </p>

      <p class="about-intro">
        With thousands of products to choose from, we bring everything you need for your household 
        right to your doorstep — from fresh vegetables and fruits to packaged foods, cleaning essentials, 
        and personal care products, all in one trusted virtual store.
      </p>

      <!-- ✅ Text + Image Section -->
      <div class="agile_about_grids">
        <div class="col-md-6 agile_about_grid_right">
          <img src="images/31.jpg" alt="Grocery Store" class="img-responsive" />
        </div>
        <div class="col-md-6 agile_about_grid_left">
          <h4>What We Offer:</h4>
          <ol>
            <li>Fresh vegetables & fruits delivered daily</li>
            <li>Grains, rice, pulses, and cooking essentials</li>
            <li>Household cleaning & hygiene products</li>
            <li>Personal care and wellness items</li>
          </ol>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- //about -->
  </div>

  <div class="clearfix"></div>

  <!-- ===== FOOTER ===== -->
  <?php include 'footer.php'; ?>

  <!-- ===== PAGE CUSTOM STYLING ===== -->
  <style>
    /* ✅ About Page Custom Styling */
    .about-intro {
      font-size: 16px;
      line-height: 1.8;
      margin-bottom: 30px;
      color: #444;
    }

    .agile_about_grids {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      margin-top: 30px;
    }

    .agile_about_grid_left ol {
      list-style: none;
      padding-left: 0;
    }

    .agile_about_grid_left ol li {
      font-size: 16px;
      margin-bottom: 10px;
      padding-left: 25px;
      position: relative;
    }

    .agile_about_grid_left ol li::before {
      content: "\2713"; /* check mark */
      position: absolute;
      left: 0;
      top: 0;
      color: green;
      font-weight: bold;
    }

    .agile_about_grid_right img {
      border-radius: 10px;
      box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
    }

    @media (max-width: 768px) {
      .agile_about_grids {
        flex-direction: column;
        text-align: center;
      }

      .agile_about_grid_left {
        margin-top: 20px;
      }
    }
  </style>

</body>
</html>
